﻿namespace Ja_Gradjanin
{
    partial class StartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCroatian = new System.Windows.Forms.Button();
            this.buttonSerbian = new System.Windows.Forms.Button();
            this.buttonBosnian = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonCroatian
            // 
            this.buttonCroatian.BackColor = System.Drawing.SystemColors.ControlLight;
            this.buttonCroatian.FlatAppearance.BorderSize = 0;
            this.buttonCroatian.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCroatian.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCroatian.ForeColor = System.Drawing.Color.Navy;
            this.buttonCroatian.Location = new System.Drawing.Point(669, 437);
            this.buttonCroatian.Name = "buttonCroatian";
            this.buttonCroatian.Size = new System.Drawing.Size(104, 34);
            this.buttonCroatian.TabIndex = 1;
            this.buttonCroatian.Text = "HRVATSKI";
            this.buttonCroatian.UseVisualStyleBackColor = false;
            this.buttonCroatian.Click += new System.EventHandler(this.buttonCroatianClick);
            // 
            // buttonSerbian
            // 
            this.buttonSerbian.BackColor = System.Drawing.SystemColors.ControlLight;
            this.buttonSerbian.FlatAppearance.BorderSize = 0;
            this.buttonSerbian.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSerbian.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSerbian.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonSerbian.Location = new System.Drawing.Point(779, 437);
            this.buttonSerbian.Name = "buttonSerbian";
            this.buttonSerbian.Size = new System.Drawing.Size(104, 34);
            this.buttonSerbian.TabIndex = 2;
            this.buttonSerbian.Text = "SRPSKI";
            this.buttonSerbian.UseVisualStyleBackColor = false;
            this.buttonSerbian.Click += new System.EventHandler(this.buttonSerbianClick);
            // 
            // buttonBosnian
            // 
            this.buttonBosnian.BackColor = System.Drawing.SystemColors.ControlLight;
            this.buttonBosnian.FlatAppearance.BorderSize = 0;
            this.buttonBosnian.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBosnian.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBosnian.ForeColor = System.Drawing.Color.Navy;
            this.buttonBosnian.Location = new System.Drawing.Point(559, 437);
            this.buttonBosnian.Name = "buttonBosnian";
            this.buttonBosnian.Size = new System.Drawing.Size(104, 34);
            this.buttonBosnian.TabIndex = 0;
            this.buttonBosnian.Text = "BOSANSKI";
            this.buttonBosnian.UseVisualStyleBackColor = false;
            this.buttonBosnian.Click += new System.EventHandler(this.buttonBosnianClick);
            // 
            // StartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImage = global::Ja_Gradjanin.Properties.Resources.start;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1055, 572);
            this.Controls.Add(this.buttonSerbian);
            this.Controls.Add(this.buttonCroatian);
            this.Controls.Add(this.buttonBosnian);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "StartForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonCroatian;
        private System.Windows.Forms.Button buttonSerbian;
        private System.Windows.Forms.Button buttonBosnian;
    }
}

