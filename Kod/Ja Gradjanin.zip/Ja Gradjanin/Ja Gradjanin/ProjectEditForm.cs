﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin
{
    public partial class ProjectEditForm : Form
    {
        private string PROJECT_NEW = @"New project";
        private string PROJECT_EDIT = @"Edit project";
        private string TYPED_DATA_NOT_VALID = @"Typed data is not valid";
        private string ERROR_OCCURED = @"Error occured";
        private string PROJECT_SAVED = @"Project saved";

        private projekat project;
        public projekat Project { get => project; set => project = value; }

        private int mode; //1 - new , 2 - edit existing

        BindingList<projekat_ucesnik> selectedStudents = new BindingList<projekat_ucesnik>();

        



        public ProjectEditForm()
        {
            InitializeComponent();
            LoadSelectedLanguageStrings();
            //panel1.Enabled = false;
            panel2.Enabled = false;

            comboBoxStatus.DataSource = Program.ProjectController.GetProjectStatusList();
            comboBoxStatus.DisplayMember = "Naziv";
            comboBoxStatus.SelectedItem = null;

            comboBoxState.DataSource = Program.TeritoryController.GetStates();
            comboBoxState.DisplayMember = "Naziv";
            comboBoxState.SelectedItem = null;

            this.Text = PROJECT_NEW;
            comboBoxRegion.Enabled = false;
            comboBoxTown.Enabled = false;
            Panel2Show(false);

            mode = 1;

            listBoxStudents.DisplayMember = "FullName";

            listBoxSelectedStudents.DataSource = selectedStudents;
            listBoxSelectedStudents.DisplayMember = "FullName";

            comboBoxLeader.DataSource = selectedStudents;
            comboBoxLeader.DisplayMember = "FullName";

            listBoxSelectedStudents.BindingContext = new BindingContext();
            comboBoxLeader.BindingContext = new BindingContext();


            if (Program.UserController.CurrentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 2)
            {
                int regionid = Program.UserController.CurrentUser.FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID;
                int stateid = (int)Program.TeritoryController.GetTeritory(regionid).FK_NadTeritorijalnaJedinica;
                foreach (teritorijalna_jedinica t in comboBoxState.Items)
                {
                    if (t.ID == stateid)
                    {
                        comboBoxState.SelectedItem = t;
                        break;
                    }
                }
                comboBoxRegionFill();
                foreach (teritorijalna_jedinica t in comboBoxRegion.Items)
                {
                    if (t.ID == regionid)
                    {
                        comboBoxRegion.SelectedItem = t;
                        break;
                    }
                }
                comboBoxTownFill();
                comboBoxTown.Enabled = true;
                comboBoxRegion.Enabled = false;
                comboBoxState.Enabled = false;


            }
            else if (Program.UserController.CurrentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 3)
            {
                int townid = Program.UserController.CurrentUser.FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID;

                int regionid = (int)Program.TeritoryController.GetTeritory(townid).FK_NadTeritorijalnaJedinica;
                int stateid = (int)Program.TeritoryController.GetTeritory(regionid).FK_NadTeritorijalnaJedinica;
                foreach (teritorijalna_jedinica t in comboBoxState.Items)
                {
                    if (t.ID == stateid)
                    {
                        comboBoxState.SelectedItem = t;
                        break;
                    }
                }
                comboBoxRegionFill();
                foreach (teritorijalna_jedinica t in comboBoxRegion.Items)
                {
                    if (t.ID == regionid)
                    {
                        comboBoxRegion.SelectedItem = t;
                        break;
                    }
                }
                foreach (teritorijalna_jedinica t in comboBoxTown.Items)
                {
                    if (t.ID == project.FK_TeritorijalnaJedinica_ID)
                    {
                        comboBoxTown.SelectedItem = t;
                        break;
                    }
                }
                comboBoxTownFill();
                comboBoxTown.Enabled = false;
                comboBoxRegion.Enabled = false;
                comboBoxState.Enabled = false;
            }


        }

        private void LoadSelectedLanguageStrings()
        {
            if (Program.LanguageResxSet != null)
            {
                labelTitle.Text = Program.LanguageResxSet.GetString("title");
                labelDescription.Text = Program.LanguageResxSet.GetString("description");
                labelStartDate.Text = Program.LanguageResxSet.GetString("startdate");
                labelEndDate.Text = Program.LanguageResxSet.GetString("enddate");
                labelBudget.Text = Program.LanguageResxSet.GetString("budget");
                labelStatus.Text = Program.LanguageResxSet.GetString("status");
                labelState.Text = Program.LanguageResxSet.GetString("state");
                labelRegion.Text = Program.LanguageResxSet.GetString("region");
                labelTown.Text = Program.LanguageResxSet.GetString("town");
                labelMentor.Text = Program.LanguageResxSet.GetString("mentor");
                labelTeacher.Text = Program.LanguageResxSet.GetString("teacher");
                labelLeader.Text = Program.LanguageResxSet.GetString("leader");
                buttonSave.Text = Program.LanguageResxSet.GetString("save");
                buttonClose.Text = Program.LanguageResxSet.GetString("close");
                labelCompleted.Text = Program.LanguageResxSet.GetString("completed%");
                buttonParticipantAdd.Text = Program.LanguageResxSet.GetString("addmissingparticipant");
                labelBalance.Text = Program.LanguageResxSet.GetString("balance");
                tabPage1.Text = Program.LanguageResxSet.GetString("incomes");
                tabPage2.Text = Program.LanguageResxSet.GetString("expenditures");
                buttonIncomeAdd.Text = Program.LanguageResxSet.GetString("add");
                buttonAddExpense.Text = Program.LanguageResxSet.GetString("add");
                buttonIncomeEdit.Text = Program.LanguageResxSet.GetString("edit");
                buttonEditExpense.Text = Program.LanguageResxSet.GetString("edit");
                buttonIncomeDelete.Text = Program.LanguageResxSet.GetString("delete");
                buttonDeleteExpense.Text = Program.LanguageResxSet.GetString("delete");
                ColumnDate.HeaderText = Program.LanguageResxSet.GetString("date");
                dataGridViewExpenseDate.HeaderText = Program.LanguageResxSet.GetString("date");
                ColumnInvestor.HeaderText = Program.LanguageResxSet.GetString("financedfrom");
                ColumnAmount.HeaderText = Program.LanguageResxSet.GetString("amount");
                dataGridViewTextBoxExpenseAmount.HeaderText = Program.LanguageResxSet.GetString("amount");
                ColumnDescription.HeaderText = Program.LanguageResxSet.GetString("description");
                dataGridViewExpensesDescription.HeaderText = Program.LanguageResxSet.GetString("description");
                labelStudents.Text = Program.LanguageResxSet.GetString("students");

                PROJECT_NEW = Program.LanguageResxSet.GetString("projectwindowtitleadd");
                PROJECT_EDIT = Program.LanguageResxSet.GetString("projectwindowtitleedit");
                TYPED_DATA_NOT_VALID = Program.LanguageResxSet.GetString("typeddatanotvalid");
                ERROR_OCCURED = Program.LanguageResxSet.GetString("erroroccured");
                PROJECT_SAVED = Program.LanguageResxSet.GetString("projectsaved");
            }
        }

        public ProjectEditForm(projekat p) : this()
        {
            project = p;
            mode = 2;
            this.Text = PROJECT_NEW;
            comboBoxRegion.Enabled = true;
            comboBoxTown.Enabled = true;
            

            textBoxTitle.Text = p.Naziv;
            textBoxDescription.Text = p.Opis;
            dateTimePickerStart.Value = p.DatumPocetka;
            dateTimePickerEnd.Value = p.DatumZavrsetka;
            numericUpDownBudget.Value = p.Budzet.GetValueOrDefault();
            numericUpDownCompleted.Value = p.ProcenatZavrsenosti * 100;
            
            foreach (projekat_status_prevod psp in comboBoxStatus.Items)
            {
                if (psp.PROJEKAT_STATUS_ID == project.FK_ProjekatStatusID)
                {
                    comboBoxStatus.SelectedItem = psp;
                    break;
                }
            }

            int regionid, stateid;
            regionid = Program.TeritoryController.GetTeritory(project.FK_TeritorijalnaJedinica_ID).FK_NadTeritorijalnaJedinica.GetValueOrDefault();
            stateid = Program.TeritoryController.GetTeritory(regionid).FK_NadTeritorijalnaJedinica.GetValueOrDefault();

                foreach (teritorijalna_jedinica t in comboBoxState.Items)
                {
                    if (t.ID == stateid)
                    {
                        comboBoxState.SelectedItem = t;
                        break;
                    }
                }
                comboBoxRegionFill();
                foreach (teritorijalna_jedinica t in comboBoxRegion.Items)
                {
                    if (t.ID == regionid)
                    {
                        comboBoxRegion.SelectedItem = t;
                        break;
                    }
                }
                comboBoxTownFill();
                foreach (teritorijalna_jedinica t in comboBoxTown.Items)
                {
                    if (t.ID == project.FK_TeritorijalnaJedinica_ID)
                    {
                        comboBoxTown.SelectedItem = t;
                        break;
                    }
                }
                foreach (teritorijalna_jedinica t in comboBoxState.Items)
                {
                    if (t.ID == regionid)
                    {
                        comboBoxState.SelectedItem = t;
                        break;
                    }
                }
              
            

            if (Program.UserController.CurrentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 2)
            {
                comboBoxState.Enabled = false;
                comboBoxRegion.Enabled = false;
            }
            else if (Program.UserController.CurrentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 3)
            {
                comboBoxState.Enabled = false;
                comboBoxRegion.Enabled = false;
                comboBoxTown.Enabled = false;
            }

            Panel2Show(true);
            FillParticipantComboBoxes(1);
            RefreshFinanceTables();

        }

        private void comboBoxStateValueChanged(object sender, EventArgs e)
        {
            if (!((ComboBox)sender).Focused)
            {
                return;
            }

            if (comboBoxState.SelectedValue == null)
            {
                comboBoxRegionFill();
                comboBoxTownFill();
                comboBoxRegion.Enabled = false;
                comboBoxTown.Enabled = false;
            }
            else
            {
                comboBoxRegionFill();
                comboBoxTownFill();
                comboBoxRegion.Enabled = true;
                comboBoxTown.Enabled = true;
            }
        }

        private void comboBoxRegionFill()
        {
            comboBoxRegion.DataSource = null;
            if (comboBoxState.SelectedValue != null)
            {
                comboBoxRegion.DataSource = Program.TeritoryController.GetSubTeritories(((teritorijalna_jedinica)comboBoxState.SelectedItem).ID, false);
                comboBoxRegion.DisplayMember = "Naziv";
            }
            
        }

        private void comboBoxTownFill()
        {
            comboBoxTown.DataSource = null;
            if (comboBoxRegion.SelectedValue != null)
            {
                comboBoxTown.DataSource = Program.TeritoryController.GetSubTeritories(((teritorijalna_jedinica)comboBoxRegion.SelectedItem).ID, false);
                comboBoxTown.DisplayMember = "Naziv";
            }
        }

        private void comboBoxRegionValueChanged(object sender, EventArgs e)
        {
            if ( ! ((ComboBox) sender).Focused)
            {
                return;
            }
            comboBoxTownFill();
            comboBoxTown.Enabled = true;
        }

        private void buttonSaveClick(object sender, EventArgs e)
        {
            SaveProject();           
        }

        private void Panel2Show(bool value)
        {
            panel2.Enabled = value;
            panel2.Visible = value;
            if (value)
            {
                this.Width = 930;
                this.MinimumSize = new Size(930, 698); 
            }
            else
            {
                this.Width = 424;
                this.MinimumSize = new Size(424, 698);
            }
            
        }

        private void buttonCloseClicked(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SaveProject()
        {
            if (textBoxTitle.Text == "" || textBoxDescription.Text == "" || comboBoxStatus.SelectedItem == null || dateTimePickerEnd.Value.Date <= dateTimePickerStart.Value.Date || comboBoxTown.SelectedItem == null)
            {
                MessageBox.Show(TYPED_DATA_NOT_VALID);
                return;
            }

            if (mode == 1)
            {
                if (Program.ProjectController.CreateProject(textBoxTitle.Text, textBoxDescription.Text, dateTimePickerStart.Value.Date, dateTimePickerEnd.Value.Date,
                    numericUpDownBudget.Value, numericUpDownCompleted.Value / 100, ((projekat_status_prevod)comboBoxStatus.SelectedItem).PROJEKAT_STATUS_ID, ((teritorijalna_jedinica)comboBoxTown.SelectedItem).ID))
                {
                    project = Program.ProjectController.GetLastCreatedProject();

                    this.Text = PROJECT_EDIT;
                    mode = 2;
                    Panel2Show(true);
                    FillParticipantComboBoxes(1);
                    MessageBox.Show(PROJECT_SAVED);
                }
                else
                {
                    MessageBox.Show(ERROR_OCCURED);
                }
            }
            else if (mode == 2)
            {
                if (Program.ProjectController.UpdateProject(this.project.ID,textBoxTitle.Text, textBoxDescription.Text, dateTimePickerStart.Value.Date, dateTimePickerEnd.Value.Date,
                    numericUpDownBudget.Value, numericUpDownCompleted.Value / 100, ((projekat_status_prevod)comboBoxStatus.SelectedItem).PROJEKAT_STATUS_ID, ((teritorijalna_jedinica)comboBoxTown.SelectedItem).ID))
                {
                    if (comboBoxMentor.SelectedItem != null)
                    {
                        Program.ProjectController.CreateProjectMentor(project.ID, ((projekat_ucesnik)comboBoxMentor.SelectedItem).ID);
                    }
                    if (comboBoxTeacher.SelectedItem != null)
                    {
                        Program.ProjectController.CreateProjectNastavnik(project.ID, ((projekat_ucesnik)comboBoxTeacher.SelectedItem).ID);
                    }
                    if (listBoxSelectedStudents.Items.Count > 0)
                    {
                        Program.ProjectController.DeleteProjectStudent(project.ID);
                        foreach (projekat_ucesnik pu in listBoxSelectedStudents.Items)
                        {
                            Program.ProjectController.CreateProjectStudent(project.ID, pu.ID);
                        }
                    }

                    if (comboBoxLeader.SelectedItem != null)
                    {
                        Program.ProjectController.CreateProjectVodja(project.ID, ((projekat_ucesnik)comboBoxLeader.SelectedItem).ID);
                    }
                    

                    this.Close();
                }
            }
        }

        // mode 1 : newly opened form ; mode 2 return from adding missing participant
        private void FillParticipantComboBoxes(int mode)
        {
            projekat_ucesnik mentor = null; ;
            projekat_ucesnik teacher = null;
            projekat_ucesnik leader = null;
            List<projekat_ucesnik> students = new List<projekat_ucesnik>();
            if (mode == 2)
            {
                mentor = comboBoxMentor.SelectedItem as projekat_ucesnik;
                teacher = comboBoxTeacher.SelectedItem as projekat_ucesnik;
                leader = comboBoxLeader.SelectedItem as projekat_ucesnik;
                foreach (projekat_ucesnik pu in listBoxSelectedStudents.Items)
                {
                    students.Add(pu);
                }
            }

            selectedStudents.Clear();

            listBoxStudents.Items.Clear();
            List<projekat_ucesnik> tmp = Program.ParticipantController.ListParticipantsByRole(1);
            listBoxStudents.DisplayMember = "FullName";
            foreach (projekat_ucesnik pu in tmp)
            {
                listBoxStudents.Items.Add(pu);
            }
            

            //listBoxSelectedStudents.Items.Clear();

            comboBoxMentor.DataSource = Program.ParticipantController.ListParticipantsByRole(3);
            comboBoxMentor.DisplayMember = "FullName";

            comboBoxTeacher.DataSource = Program.ParticipantController.ListParticipantsByRole(2);
            comboBoxTeacher.DisplayMember = "FullName";


            comboBoxMentor.SelectedItem = null;
            comboBoxTeacher.SelectedItem = null;
            comboBoxLeader.SelectedItem = null;

            if (mode == 1)
            {


                if (Program.ProjectController.GetProjectMentor(project.ID) != null)
                {
                    foreach (projekat_ucesnik pu in comboBoxMentor.Items)
                    {
                        if (pu.ID == Program.ProjectController.GetProjectMentor(project.ID).FK_UcesnikProjektaID)
                        {
                            comboBoxMentor.SelectedItem = pu;
                            break;
                        }
                    }
                }

                if (Program.ProjectController.GetProjectNastavnik(project.ID) != null)
                {
                    foreach (projekat_ucesnik pu in comboBoxTeacher.Items)
                    {
                        if (pu.ID == Program.ProjectController.GetProjectNastavnik(project.ID).FK_UcesnikProjektaID)
                        {
                            comboBoxTeacher.SelectedItem = pu;
                            break;
                        }
                    }
                }

                List<projekat_ucenik> projectstudents = Program.ProjectController.GetProjectStudents(project.ID);
                if (projectstudents.Count > 0)
                {
                    foreach (projekat_ucenik pu in projectstudents)
                    {
                        foreach(projekat_ucesnik uc in listBoxStudents.Items)
                        {
                            if (pu.FK__UcesnikProjektaID == uc.ID)
                            {
                                selectedStudents.Add(uc);
                                listBoxStudents.Items.Remove(uc);
                                break;
                            }
                        }
                    }
                }

                if (Program.ProjectController.GetProjectVodja(project.ID) != null)
                {
                    foreach (projekat_ucesnik pu in comboBoxLeader.Items)
                    {
                        if (pu.ID == Program.ProjectController.GetProjectVodja(project.ID).FK_UcesnikProjektaID)
                        {
                            comboBoxLeader.SelectedItem = pu;
                            break;
                        }
                    }
                }
                    
            }
            else if (mode == 2)
            {
                if (mentor != null)
                {
                    foreach (projekat_ucesnik pu in comboBoxMentor.Items)
                    {
                        if (pu.ID == mentor.ID)
                        {
                            comboBoxMentor.SelectedItem = pu;
                            break;
                        }
                    }
                }

                if (teacher != null)
                {
                    foreach (projekat_ucesnik pu in comboBoxTeacher.Items)
                    {
                        if (pu.ID == teacher.ID)
                        {
                            comboBoxTeacher.SelectedItem = pu;
                            break;
                        }
                    }
                }

                if (students.Count > 0)
                {
                    foreach (projekat_ucesnik pu in students)
                    {
                        foreach (projekat_ucesnik uc in listBoxStudents.Items)
                        {
                            if (pu.ID == uc.ID)
                            {
                                selectedStudents.Add(uc);
                                listBoxStudents.Items.Remove(uc);
                                break;
                            }
                        }
                    }
                }

                if (leader != null)
                {
                    foreach (projekat_ucesnik pu in comboBoxLeader.Items)
                    {
                        if (pu.ID == leader.ID)
                        {
                            comboBoxLeader.SelectedItem = pu;
                            break;
                        }
                    }
                }
            }
        }

        private void buttonParticipantAddClick(object sender, EventArgs e)
        {
            ParticipantEditForm pef = new ParticipantEditForm();
            pef.ShowDialog();
            FillParticipantComboBoxes(2);
        }

        private void buttonAddStudentClick(object sender, EventArgs e)
        {
            if (listBoxStudents.SelectedItem != null)
            {
                selectedStudents.Add((projekat_ucesnik) listBoxStudents.SelectedItem);
                listBoxStudents.Items.Remove(listBoxStudents.SelectedItem);
            }
        }

        private void buttonDeleteStudentClick(object sender, EventArgs e)
        {
            if (listBoxSelectedStudents.SelectedItem != null)
            {
                listBoxStudents.Items.Add(listBoxSelectedStudents.SelectedItem);
                selectedStudents.Remove((projekat_ucesnik)listBoxSelectedStudents.SelectedItem);
            }
        }

        private void listBoxSelectedStudentsSelectedIndexChanged(object sender, EventArgs e)
        {
            return;
        }

        private void listBoxSelectedStudentsSelectedValueChanged(object sender, EventArgs e)
        {
            return;
        }

        private void RefreshFinanceTables()
        {
            dataGridViewExpenses.Rows.Clear();
            dataGridViewIncomes.Rows.Clear();

            decimal sum = 0;

            List<prihod> incomes = Program.FinanceController.GetProjectIncomes(project.ID);
            foreach (prihod p in incomes)
            {
                object[] rowdata = new object[5];
                rowdata[0] = p.ID;
                rowdata[1] = p.Datum.Date.ToShortDateString();
                rowdata[2] = p.FinansiranOd;
                rowdata[3] = p.Opis;
                rowdata[4] = p.NovcaniIznos;
                dataGridViewIncomes.Rows.Add(rowdata);
                sum += p.NovcaniIznos;
            }

            List<rashod> expenditures = Program.FinanceController.GetProjectExpenditures(project.ID);
            foreach (rashod r in expenditures)
            {
                object[] rowdata = new object[4];
                rowdata[0] = r.ID;
                rowdata[1] = r.Datum.Date.ToShortDateString();
                rowdata[2] = r.Opis;
                rowdata[3] = r.NovcaniIznos;
                dataGridViewExpenses.Rows.Add(rowdata);
                sum -= r.NovcaniIznos;
            }

            textBoxBalance.Text = sum.ToString();
        }

        private void buttonIncomeDeleteClicked(object sender, EventArgs e)
        {
            if (dataGridViewIncomes.SelectedRows.Count > 0)
            {
                Program.FinanceController.DeleteIncome((int)dataGridViewIncomes.SelectedRows[0].Cells[0].Value);
                RefreshFinanceTables();
            }
        }

        private void buttonDeleteExpenseClicked(object sender, EventArgs e)
        {
            if (dataGridViewExpenses.SelectedRows.Count > 0)
            {
                Program.FinanceController.DeleteExpenditure((int)dataGridViewExpenses.SelectedRows[0].Cells[0].Value);
                RefreshFinanceTables();
            }
        }

        private void buttonIncomeAddClicked(object sender, EventArgs e)
        {
            FinancesForm ff = new FinancesForm(project.ID, 1);
            ff.ShowDialog();
            RefreshFinanceTables();
        }

        private void buttonIncomeEditClicked(object sender, EventArgs e)
        {
            if (dataGridViewIncomes.SelectedRows.Count > 0)
            {
                FinancesForm ff = new FinancesForm(project.ID, 1, (int)dataGridViewIncomes.SelectedRows[0].Cells[0].Value);
                ff.ShowDialog();
                RefreshFinanceTables();
            }
                
        }

        private void buttonAddExpenseClicked(object sender, EventArgs e)
        {
            FinancesForm ff = new FinancesForm(project.ID, 2);
            ff.ShowDialog();
            RefreshFinanceTables();
        }

        private void buttonEditExpenseClicked(object sender, EventArgs e)
        {
            if (dataGridViewIncomes.SelectedRows.Count > 0)
            {
                FinancesForm ff = new FinancesForm(project.ID, 2, (int)dataGridViewExpenses.SelectedRows[0].Cells[0].Value);
                ff.ShowDialog();
                RefreshFinanceTables();
            }
                
        }
    }
}
