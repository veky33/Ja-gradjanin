﻿namespace Ja_Gradjanin
{
    partial class ProjectEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.comboBoxTeacher = new System.Windows.Forms.ComboBox();
            this.labelTeacher = new System.Windows.Forms.Label();
            this.comboBoxMentor = new System.Windows.Forms.ComboBox();
            this.labelMentor = new System.Windows.Forms.Label();
            this.comboBoxLeader = new System.Windows.Forms.ComboBox();
            this.labelLeader = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelBalance = new System.Windows.Forms.Label();
            this.textBoxBalance = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonIncomeDelete = new System.Windows.Forms.Button();
            this.buttonIncomeEdit = new System.Windows.Forms.Button();
            this.buttonIncomeAdd = new System.Windows.Forms.Button();
            this.dataGridViewIncomes = new System.Windows.Forms.DataGridView();
            this.ColumnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnInvestor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonDeleteExpense = new System.Windows.Forms.Button();
            this.buttonEditExpense = new System.Windows.Forms.Button();
            this.buttonAddExpense = new System.Windows.Forms.Button();
            this.dataGridViewExpenses = new System.Windows.Forms.DataGridView();
            this.dataGridViewExpenseID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewExpenseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewExpensesDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxExpenseAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelStudents = new System.Windows.Forms.Label();
            this.buttonAddStudent = new System.Windows.Forms.Button();
            this.listBoxSelectedStudents = new System.Windows.Forms.ListBox();
            this.listBoxStudents = new System.Windows.Forms.ListBox();
            this.buttonDeleteStudent = new System.Windows.Forms.Button();
            this.buttonParticipantAdd = new System.Windows.Forms.Button();
            this.labelTitle = new System.Windows.Forms.Label();
            this.textBoxTitle = new System.Windows.Forms.TextBox();
            this.labelDescription = new System.Windows.Forms.Label();
            this.textBoxDescription = new System.Windows.Forms.TextBox();
            this.dateTimePickerStart = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerEnd = new System.Windows.Forms.DateTimePicker();
            this.numericUpDownBudget = new System.Windows.Forms.NumericUpDown();
            this.labelStartDate = new System.Windows.Forms.Label();
            this.comboBoxRegion = new System.Windows.Forms.ComboBox();
            this.labelRegion = new System.Windows.Forms.Label();
            this.labelEndDate = new System.Windows.Forms.Label();
            this.labelBudget = new System.Windows.Forms.Label();
            this.labelTown = new System.Windows.Forms.Label();
            this.labelStatus = new System.Windows.Forms.Label();
            this.comboBoxStatus = new System.Windows.Forms.ComboBox();
            this.comboBoxTown = new System.Windows.Forms.ComboBox();
            this.labelState = new System.Windows.Forms.Label();
            this.comboBoxState = new System.Windows.Forms.ComboBox();
            this.labelCompleted = new System.Windows.Forms.Label();
            this.numericUpDownCompleted = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIncomes)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewExpenses)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBudget)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCompleted)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonSave
            // 
            this.buttonSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonSave.Location = new System.Drawing.Point(12, 624);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(75, 23);
            this.buttonSave.TabIndex = 27;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSaveClick);
            // 
            // buttonClose
            // 
            this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonClose.Location = new System.Drawing.Point(118, 624);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(75, 23);
            this.buttonClose.TabIndex = 29;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonCloseClicked);
            // 
            // comboBoxTeacher
            // 
            this.comboBoxTeacher.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxTeacher.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBoxTeacher.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBoxTeacher.FormattingEnabled = true;
            this.comboBoxTeacher.Location = new System.Drawing.Point(103, 48);
            this.comboBoxTeacher.Name = "comboBoxTeacher";
            this.comboBoxTeacher.Size = new System.Drawing.Size(148, 21);
            this.comboBoxTeacher.TabIndex = 24;
            // 
            // labelTeacher
            // 
            this.labelTeacher.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelTeacher.AutoSize = true;
            this.labelTeacher.Location = new System.Drawing.Point(9, 48);
            this.labelTeacher.Name = "labelTeacher";
            this.labelTeacher.Size = new System.Drawing.Size(47, 13);
            this.labelTeacher.TabIndex = 23;
            this.labelTeacher.Text = "Teacher";
            // 
            // comboBoxMentor
            // 
            this.comboBoxMentor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxMentor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBoxMentor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBoxMentor.FormattingEnabled = true;
            this.comboBoxMentor.Location = new System.Drawing.Point(103, 10);
            this.comboBoxMentor.Name = "comboBoxMentor";
            this.comboBoxMentor.Size = new System.Drawing.Size(148, 21);
            this.comboBoxMentor.TabIndex = 15;
            // 
            // labelMentor
            // 
            this.labelMentor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelMentor.AutoSize = true;
            this.labelMentor.Location = new System.Drawing.Point(8, 18);
            this.labelMentor.Name = "labelMentor";
            this.labelMentor.Size = new System.Drawing.Size(40, 13);
            this.labelMentor.TabIndex = 14;
            this.labelMentor.Text = "Mentor";
            // 
            // comboBoxLeader
            // 
            this.comboBoxLeader.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxLeader.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBoxLeader.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBoxLeader.FormattingEnabled = true;
            this.comboBoxLeader.Location = new System.Drawing.Point(100, 215);
            this.comboBoxLeader.Name = "comboBoxLeader";
            this.comboBoxLeader.Size = new System.Drawing.Size(148, 21);
            this.comboBoxLeader.TabIndex = 20;
            // 
            // labelLeader
            // 
            this.labelLeader.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelLeader.AutoSize = true;
            this.labelLeader.Location = new System.Drawing.Point(8, 218);
            this.labelLeader.Name = "labelLeader";
            this.labelLeader.Size = new System.Drawing.Size(40, 13);
            this.labelLeader.TabIndex = 19;
            this.labelLeader.Text = "Leader";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.labelStudents);
            this.panel2.Controls.Add(this.buttonAddStudent);
            this.panel2.Controls.Add(this.listBoxSelectedStudents);
            this.panel2.Controls.Add(this.listBoxStudents);
            this.panel2.Controls.Add(this.buttonDeleteStudent);
            this.panel2.Controls.Add(this.buttonParticipantAdd);
            this.panel2.Controls.Add(this.labelLeader);
            this.panel2.Controls.Add(this.comboBoxLeader);
            this.panel2.Controls.Add(this.labelMentor);
            this.panel2.Controls.Add(this.comboBoxMentor);
            this.panel2.Controls.Add(this.labelTeacher);
            this.panel2.Controls.Add(this.comboBoxTeacher);
            this.panel2.Location = new System.Drawing.Point(432, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(470, 603);
            this.panel2.TabIndex = 30;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.labelBalance);
            this.groupBox1.Controls.Add(this.textBoxBalance);
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Location = new System.Drawing.Point(3, 242);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(437, 358);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            // 
            // labelBalance
            // 
            this.labelBalance.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelBalance.AutoSize = true;
            this.labelBalance.Location = new System.Drawing.Point(12, 16);
            this.labelBalance.Name = "labelBalance";
            this.labelBalance.Size = new System.Drawing.Size(46, 13);
            this.labelBalance.TabIndex = 39;
            this.labelBalance.Text = "Balance";
            // 
            // textBoxBalance
            // 
            this.textBoxBalance.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxBalance.Location = new System.Drawing.Point(83, 13);
            this.textBoxBalance.Name = "textBoxBalance";
            this.textBoxBalance.ReadOnly = true;
            this.textBoxBalance.Size = new System.Drawing.Size(100, 20);
            this.textBoxBalance.TabIndex = 40;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(6, 39);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(431, 313);
            this.tabControl1.TabIndex = 41;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.buttonIncomeDelete);
            this.tabPage1.Controls.Add(this.buttonIncomeEdit);
            this.tabPage1.Controls.Add(this.buttonIncomeAdd);
            this.tabPage1.Controls.Add(this.dataGridViewIncomes);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(423, 287);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Incomes";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // buttonIncomeDelete
            // 
            this.buttonIncomeDelete.Location = new System.Drawing.Point(168, 6);
            this.buttonIncomeDelete.Name = "buttonIncomeDelete";
            this.buttonIncomeDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonIncomeDelete.TabIndex = 42;
            this.buttonIncomeDelete.Text = "Delete";
            this.buttonIncomeDelete.UseVisualStyleBackColor = true;
            this.buttonIncomeDelete.Click += new System.EventHandler(this.buttonIncomeDeleteClicked);
            // 
            // buttonIncomeEdit
            // 
            this.buttonIncomeEdit.Location = new System.Drawing.Point(87, 6);
            this.buttonIncomeEdit.Name = "buttonIncomeEdit";
            this.buttonIncomeEdit.Size = new System.Drawing.Size(75, 23);
            this.buttonIncomeEdit.TabIndex = 41;
            this.buttonIncomeEdit.Text = "Edit";
            this.buttonIncomeEdit.UseVisualStyleBackColor = true;
            this.buttonIncomeEdit.Click += new System.EventHandler(this.buttonIncomeEditClicked);
            // 
            // buttonIncomeAdd
            // 
            this.buttonIncomeAdd.Location = new System.Drawing.Point(8, 6);
            this.buttonIncomeAdd.Name = "buttonIncomeAdd";
            this.buttonIncomeAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonIncomeAdd.TabIndex = 40;
            this.buttonIncomeAdd.Text = "Add";
            this.buttonIncomeAdd.UseVisualStyleBackColor = true;
            this.buttonIncomeAdd.Click += new System.EventHandler(this.buttonIncomeAddClicked);
            // 
            // dataGridViewIncomes
            // 
            this.dataGridViewIncomes.AllowUserToAddRows = false;
            this.dataGridViewIncomes.AllowUserToDeleteRows = false;
            this.dataGridViewIncomes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewIncomes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnID,
            this.ColumnDate,
            this.ColumnInvestor,
            this.ColumnDescription,
            this.ColumnAmount});
            this.dataGridViewIncomes.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridViewIncomes.Location = new System.Drawing.Point(3, 52);
            this.dataGridViewIncomes.MultiSelect = false;
            this.dataGridViewIncomes.Name = "dataGridViewIncomes";
            this.dataGridViewIncomes.ReadOnly = true;
            this.dataGridViewIncomes.RowHeadersVisible = false;
            this.dataGridViewIncomes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewIncomes.Size = new System.Drawing.Size(417, 232);
            this.dataGridViewIncomes.TabIndex = 39;
            // 
            // ColumnID
            // 
            this.ColumnID.HeaderText = "ID";
            this.ColumnID.Name = "ColumnID";
            this.ColumnID.ReadOnly = true;
            this.ColumnID.Visible = false;
            // 
            // ColumnDate
            // 
            this.ColumnDate.HeaderText = "Date";
            this.ColumnDate.Name = "ColumnDate";
            this.ColumnDate.ReadOnly = true;
            // 
            // ColumnInvestor
            // 
            this.ColumnInvestor.HeaderText = "Investor";
            this.ColumnInvestor.Name = "ColumnInvestor";
            this.ColumnInvestor.ReadOnly = true;
            // 
            // ColumnDescription
            // 
            this.ColumnDescription.HeaderText = "Description";
            this.ColumnDescription.Name = "ColumnDescription";
            this.ColumnDescription.ReadOnly = true;
            // 
            // ColumnAmount
            // 
            this.ColumnAmount.HeaderText = "Amount";
            this.ColumnAmount.Name = "ColumnAmount";
            this.ColumnAmount.ReadOnly = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.buttonDeleteExpense);
            this.tabPage2.Controls.Add(this.buttonEditExpense);
            this.tabPage2.Controls.Add(this.buttonAddExpense);
            this.tabPage2.Controls.Add(this.dataGridViewExpenses);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(423, 287);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Expenses";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // buttonDeleteExpense
            // 
            this.buttonDeleteExpense.Location = new System.Drawing.Point(168, 6);
            this.buttonDeleteExpense.Name = "buttonDeleteExpense";
            this.buttonDeleteExpense.Size = new System.Drawing.Size(75, 23);
            this.buttonDeleteExpense.TabIndex = 45;
            this.buttonDeleteExpense.Text = "Delete";
            this.buttonDeleteExpense.UseVisualStyleBackColor = true;
            this.buttonDeleteExpense.Click += new System.EventHandler(this.buttonDeleteExpenseClicked);
            // 
            // buttonEditExpense
            // 
            this.buttonEditExpense.Location = new System.Drawing.Point(87, 6);
            this.buttonEditExpense.Name = "buttonEditExpense";
            this.buttonEditExpense.Size = new System.Drawing.Size(75, 23);
            this.buttonEditExpense.TabIndex = 44;
            this.buttonEditExpense.Text = "Edit";
            this.buttonEditExpense.UseVisualStyleBackColor = true;
            this.buttonEditExpense.Click += new System.EventHandler(this.buttonEditExpenseClicked);
            // 
            // buttonAddExpense
            // 
            this.buttonAddExpense.Location = new System.Drawing.Point(8, 6);
            this.buttonAddExpense.Name = "buttonAddExpense";
            this.buttonAddExpense.Size = new System.Drawing.Size(75, 23);
            this.buttonAddExpense.TabIndex = 43;
            this.buttonAddExpense.Text = "Add";
            this.buttonAddExpense.UseVisualStyleBackColor = true;
            this.buttonAddExpense.Click += new System.EventHandler(this.buttonAddExpenseClicked);
            // 
            // dataGridViewExpenses
            // 
            this.dataGridViewExpenses.AllowUserToAddRows = false;
            this.dataGridViewExpenses.AllowUserToDeleteRows = false;
            this.dataGridViewExpenses.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewExpenses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewExpenses.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewExpenseID,
            this.dataGridViewExpenseDate,
            this.dataGridViewExpensesDescription,
            this.dataGridViewTextBoxExpenseAmount});
            this.dataGridViewExpenses.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridViewExpenses.Location = new System.Drawing.Point(3, 52);
            this.dataGridViewExpenses.MultiSelect = false;
            this.dataGridViewExpenses.Name = "dataGridViewExpenses";
            this.dataGridViewExpenses.ReadOnly = true;
            this.dataGridViewExpenses.RowHeadersVisible = false;
            this.dataGridViewExpenses.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewExpenses.Size = new System.Drawing.Size(417, 232);
            this.dataGridViewExpenses.TabIndex = 40;
            // 
            // dataGridViewExpenseID
            // 
            this.dataGridViewExpenseID.HeaderText = "ID";
            this.dataGridViewExpenseID.Name = "dataGridViewExpenseID";
            this.dataGridViewExpenseID.ReadOnly = true;
            this.dataGridViewExpenseID.Visible = false;
            // 
            // dataGridViewExpenseDate
            // 
            this.dataGridViewExpenseDate.HeaderText = "Date";
            this.dataGridViewExpenseDate.Name = "dataGridViewExpenseDate";
            this.dataGridViewExpenseDate.ReadOnly = true;
            // 
            // dataGridViewExpensesDescription
            // 
            this.dataGridViewExpensesDescription.HeaderText = "Description";
            this.dataGridViewExpensesDescription.Name = "dataGridViewExpensesDescription";
            this.dataGridViewExpensesDescription.ReadOnly = true;
            // 
            // dataGridViewTextBoxExpenseAmount
            // 
            this.dataGridViewTextBoxExpenseAmount.HeaderText = "Amount";
            this.dataGridViewTextBoxExpenseAmount.Name = "dataGridViewTextBoxExpenseAmount";
            this.dataGridViewTextBoxExpenseAmount.ReadOnly = true;
            // 
            // labelStudents
            // 
            this.labelStudents.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelStudents.AutoSize = true;
            this.labelStudents.Location = new System.Drawing.Point(9, 80);
            this.labelStudents.Name = "labelStudents";
            this.labelStudents.Size = new System.Drawing.Size(49, 13);
            this.labelStudents.TabIndex = 42;
            this.labelStudents.Text = "Students";
            // 
            // buttonAddStudent
            // 
            this.buttonAddStudent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonAddStudent.Location = new System.Drawing.Point(206, 188);
            this.buttonAddStudent.Name = "buttonAddStudent";
            this.buttonAddStudent.Size = new System.Drawing.Size(25, 21);
            this.buttonAddStudent.TabIndex = 38;
            this.buttonAddStudent.Text = "<";
            this.buttonAddStudent.UseVisualStyleBackColor = true;
            this.buttonAddStudent.Click += new System.EventHandler(this.buttonAddStudentClick);
            // 
            // listBoxSelectedStudents
            // 
            this.listBoxSelectedStudents.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxSelectedStudents.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.listBoxSelectedStudents.FormattingEnabled = true;
            this.listBoxSelectedStudents.Location = new System.Drawing.Point(11, 101);
            this.listBoxSelectedStudents.Name = "listBoxSelectedStudents";
            this.listBoxSelectedStudents.Size = new System.Drawing.Size(189, 108);
            this.listBoxSelectedStudents.TabIndex = 37;
            this.listBoxSelectedStudents.SelectedIndexChanged += new System.EventHandler(this.listBoxSelectedStudentsSelectedIndexChanged);
            this.listBoxSelectedStudents.SelectedValueChanged += new System.EventHandler(this.listBoxSelectedStudentsSelectedValueChanged);
            // 
            // listBoxStudents
            // 
            this.listBoxStudents.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxStudents.FormattingEnabled = true;
            this.listBoxStudents.Location = new System.Drawing.Point(237, 101);
            this.listBoxStudents.Name = "listBoxStudents";
            this.listBoxStudents.Size = new System.Drawing.Size(189, 108);
            this.listBoxStudents.TabIndex = 36;
            // 
            // buttonDeleteStudent
            // 
            this.buttonDeleteStudent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDeleteStudent.Location = new System.Drawing.Point(206, 101);
            this.buttonDeleteStudent.Name = "buttonDeleteStudent";
            this.buttonDeleteStudent.Size = new System.Drawing.Size(25, 21);
            this.buttonDeleteStudent.TabIndex = 35;
            this.buttonDeleteStudent.Text = ">";
            this.buttonDeleteStudent.UseVisualStyleBackColor = true;
            this.buttonDeleteStudent.Click += new System.EventHandler(this.buttonDeleteStudentClick);
            // 
            // buttonParticipantAdd
            // 
            this.buttonParticipantAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonParticipantAdd.Location = new System.Drawing.Point(349, 25);
            this.buttonParticipantAdd.Name = "buttonParticipantAdd";
            this.buttonParticipantAdd.Size = new System.Drawing.Size(80, 47);
            this.buttonParticipantAdd.TabIndex = 30;
            this.buttonParticipantAdd.Text = "Add missing participant";
            this.buttonParticipantAdd.UseVisualStyleBackColor = true;
            this.buttonParticipantAdd.Click += new System.EventHandler(this.buttonParticipantAddClick);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Location = new System.Drawing.Point(2, 11);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(27, 13);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Title";
            // 
            // textBoxTitle
            // 
            this.textBoxTitle.Location = new System.Drawing.Point(106, 8);
            this.textBoxTitle.Name = "textBoxTitle";
            this.textBoxTitle.Size = new System.Drawing.Size(221, 20);
            this.textBoxTitle.TabIndex = 1;
            // 
            // labelDescription
            // 
            this.labelDescription.AutoSize = true;
            this.labelDescription.Location = new System.Drawing.Point(5, 48);
            this.labelDescription.Name = "labelDescription";
            this.labelDescription.Size = new System.Drawing.Size(60, 13);
            this.labelDescription.TabIndex = 2;
            this.labelDescription.Text = "Description";
            // 
            // textBoxDescription
            // 
            this.textBoxDescription.AcceptsReturn = true;
            this.textBoxDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxDescription.Location = new System.Drawing.Point(106, 48);
            this.textBoxDescription.Multiline = true;
            this.textBoxDescription.Name = "textBoxDescription";
            this.textBoxDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDescription.Size = new System.Drawing.Size(186, 120);
            this.textBoxDescription.TabIndex = 3;
            // 
            // dateTimePickerStart
            // 
            this.dateTimePickerStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dateTimePickerStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerStart.Location = new System.Drawing.Point(106, 208);
            this.dateTimePickerStart.Name = "dateTimePickerStart";
            this.dateTimePickerStart.Size = new System.Drawing.Size(94, 20);
            this.dateTimePickerStart.TabIndex = 4;
            // 
            // dateTimePickerEnd
            // 
            this.dateTimePickerEnd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dateTimePickerEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerEnd.Location = new System.Drawing.Point(106, 252);
            this.dateTimePickerEnd.Name = "dateTimePickerEnd";
            this.dateTimePickerEnd.Size = new System.Drawing.Size(94, 20);
            this.dateTimePickerEnd.TabIndex = 5;
            // 
            // numericUpDownBudget
            // 
            this.numericUpDownBudget.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numericUpDownBudget.DecimalPlaces = 2;
            this.numericUpDownBudget.Location = new System.Drawing.Point(106, 309);
            this.numericUpDownBudget.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDownBudget.Name = "numericUpDownBudget";
            this.numericUpDownBudget.Size = new System.Drawing.Size(85, 20);
            this.numericUpDownBudget.TabIndex = 6;
            this.numericUpDownBudget.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelStartDate
            // 
            this.labelStartDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelStartDate.AutoSize = true;
            this.labelStartDate.Location = new System.Drawing.Point(5, 214);
            this.labelStartDate.Name = "labelStartDate";
            this.labelStartDate.Size = new System.Drawing.Size(53, 13);
            this.labelStartDate.TabIndex = 7;
            this.labelStartDate.Text = "Start date";
            // 
            // comboBoxRegion
            // 
            this.comboBoxRegion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBoxRegion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRegion.FormattingEnabled = true;
            this.comboBoxRegion.Location = new System.Drawing.Point(106, 425);
            this.comboBoxRegion.Name = "comboBoxRegion";
            this.comboBoxRegion.Size = new System.Drawing.Size(199, 21);
            this.comboBoxRegion.TabIndex = 10;
            this.comboBoxRegion.SelectedValueChanged += new System.EventHandler(this.comboBoxRegionValueChanged);
            // 
            // labelRegion
            // 
            this.labelRegion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelRegion.AutoSize = true;
            this.labelRegion.Location = new System.Drawing.Point(5, 428);
            this.labelRegion.Name = "labelRegion";
            this.labelRegion.Size = new System.Drawing.Size(41, 13);
            this.labelRegion.TabIndex = 11;
            this.labelRegion.Text = "Region";
            // 
            // labelEndDate
            // 
            this.labelEndDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelEndDate.AutoSize = true;
            this.labelEndDate.Location = new System.Drawing.Point(5, 258);
            this.labelEndDate.Name = "labelEndDate";
            this.labelEndDate.Size = new System.Drawing.Size(50, 13);
            this.labelEndDate.TabIndex = 8;
            this.labelEndDate.Text = "End date";
            // 
            // labelBudget
            // 
            this.labelBudget.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelBudget.AutoSize = true;
            this.labelBudget.Location = new System.Drawing.Point(5, 311);
            this.labelBudget.Name = "labelBudget";
            this.labelBudget.Size = new System.Drawing.Size(41, 13);
            this.labelBudget.TabIndex = 9;
            this.labelBudget.Text = "Budget";
            // 
            // labelTown
            // 
            this.labelTown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelTown.AutoSize = true;
            this.labelTown.Location = new System.Drawing.Point(5, 462);
            this.labelTown.Name = "labelTown";
            this.labelTown.Size = new System.Drawing.Size(34, 13);
            this.labelTown.TabIndex = 12;
            this.labelTown.Text = "Town";
            // 
            // labelStatus
            // 
            this.labelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelStatus.AutoSize = true;
            this.labelStatus.Location = new System.Drawing.Point(5, 346);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(37, 13);
            this.labelStatus.TabIndex = 16;
            this.labelStatus.Text = "Status";
            // 
            // comboBoxStatus
            // 
            this.comboBoxStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBoxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStatus.FormattingEnabled = true;
            this.comboBoxStatus.Location = new System.Drawing.Point(106, 346);
            this.comboBoxStatus.Name = "comboBoxStatus";
            this.comboBoxStatus.Size = new System.Drawing.Size(149, 21);
            this.comboBoxStatus.TabIndex = 17;
            // 
            // comboBoxTown
            // 
            this.comboBoxTown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBoxTown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTown.FormattingEnabled = true;
            this.comboBoxTown.Location = new System.Drawing.Point(106, 462);
            this.comboBoxTown.Name = "comboBoxTown";
            this.comboBoxTown.Size = new System.Drawing.Size(199, 21);
            this.comboBoxTown.TabIndex = 13;
            // 
            // labelState
            // 
            this.labelState.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelState.AutoSize = true;
            this.labelState.Location = new System.Drawing.Point(5, 391);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(32, 13);
            this.labelState.TabIndex = 18;
            this.labelState.Text = "State";
            // 
            // comboBoxState
            // 
            this.comboBoxState.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBoxState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxState.FormattingEnabled = true;
            this.comboBoxState.Location = new System.Drawing.Point(106, 388);
            this.comboBoxState.Name = "comboBoxState";
            this.comboBoxState.Size = new System.Drawing.Size(199, 21);
            this.comboBoxState.TabIndex = 19;
            this.comboBoxState.SelectedValueChanged += new System.EventHandler(this.comboBoxStateValueChanged);
            // 
            // labelCompleted
            // 
            this.labelCompleted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelCompleted.AutoSize = true;
            this.labelCompleted.Location = new System.Drawing.Point(8, 503);
            this.labelCompleted.Name = "labelCompleted";
            this.labelCompleted.Size = new System.Drawing.Size(68, 13);
            this.labelCompleted.TabIndex = 20;
            this.labelCompleted.Text = "Completed %";
            // 
            // numericUpDownCompleted
            // 
            this.numericUpDownCompleted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numericUpDownCompleted.Location = new System.Drawing.Point(106, 503);
            this.numericUpDownCompleted.Name = "numericUpDownCompleted";
            this.numericUpDownCompleted.Size = new System.Drawing.Size(53, 20);
            this.numericUpDownCompleted.TabIndex = 21;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.numericUpDownCompleted);
            this.panel1.Controls.Add(this.labelCompleted);
            this.panel1.Controls.Add(this.comboBoxState);
            this.panel1.Controls.Add(this.labelState);
            this.panel1.Controls.Add(this.comboBoxTown);
            this.panel1.Controls.Add(this.comboBoxStatus);
            this.panel1.Controls.Add(this.labelStatus);
            this.panel1.Controls.Add(this.labelTown);
            this.panel1.Controls.Add(this.labelBudget);
            this.panel1.Controls.Add(this.labelEndDate);
            this.panel1.Controls.Add(this.labelRegion);
            this.panel1.Controls.Add(this.comboBoxRegion);
            this.panel1.Controls.Add(this.labelStartDate);
            this.panel1.Controls.Add(this.numericUpDownBudget);
            this.panel1.Controls.Add(this.dateTimePickerEnd);
            this.panel1.Controls.Add(this.dateTimePickerStart);
            this.panel1.Controls.Add(this.textBoxDescription);
            this.panel1.Controls.Add(this.labelDescription);
            this.panel1.Controls.Add(this.textBoxTitle);
            this.panel1.Controls.Add(this.labelTitle);
            this.panel1.Location = new System.Drawing.Point(12, 24);
            this.panel1.MinimumSize = new System.Drawing.Size(388, 535);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(388, 535);
            this.panel1.TabIndex = 22;
            // 
            // ProjectEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 659);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.panel1);
            this.MinimizeBox = false;
            this.Name = "ProjectEditForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProjectEditForm";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIncomes)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewExpenses)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBudget)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCompleted)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.ComboBox comboBoxTeacher;
        private System.Windows.Forms.Label labelTeacher;
        private System.Windows.Forms.ComboBox comboBoxMentor;
        private System.Windows.Forms.Label labelMentor;
        private System.Windows.Forms.ComboBox comboBoxLeader;
        private System.Windows.Forms.Label labelLeader;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonParticipantAdd;
        private System.Windows.Forms.Button buttonDeleteStudent;
        private System.Windows.Forms.ListBox listBoxStudents;
        private System.Windows.Forms.ListBox listBoxSelectedStudents;
        private System.Windows.Forms.Button buttonAddStudent;
        private System.Windows.Forms.TextBox textBoxBalance;
        private System.Windows.Forms.Label labelBalance;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button buttonIncomeDelete;
        private System.Windows.Forms.Button buttonIncomeEdit;
        private System.Windows.Forms.Button buttonIncomeAdd;
        private System.Windows.Forms.DataGridView dataGridViewIncomes;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnInvestor;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnAmount;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button buttonDeleteExpense;
        private System.Windows.Forms.Button buttonEditExpense;
        private System.Windows.Forms.Button buttonAddExpense;
        private System.Windows.Forms.DataGridView dataGridViewExpenses;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewExpenseID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewExpenseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewExpensesDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxExpenseAmount;
        private System.Windows.Forms.Label labelStudents;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.TextBox textBoxTitle;
        private System.Windows.Forms.Label labelDescription;
        private System.Windows.Forms.TextBox textBoxDescription;
        private System.Windows.Forms.DateTimePicker dateTimePickerStart;
        private System.Windows.Forms.DateTimePicker dateTimePickerEnd;
        private System.Windows.Forms.NumericUpDown numericUpDownBudget;
        private System.Windows.Forms.Label labelStartDate;
        private System.Windows.Forms.ComboBox comboBoxRegion;
        private System.Windows.Forms.Label labelRegion;
        private System.Windows.Forms.Label labelEndDate;
        private System.Windows.Forms.Label labelBudget;
        private System.Windows.Forms.Label labelTown;
        private System.Windows.Forms.Label labelStatus;
        private System.Windows.Forms.ComboBox comboBoxStatus;
        private System.Windows.Forms.ComboBox comboBoxTown;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.ComboBox comboBoxState;
        private System.Windows.Forms.Label labelCompleted;
        private System.Windows.Forms.NumericUpDown numericUpDownCompleted;
        private System.Windows.Forms.Panel panel1;
    }
}