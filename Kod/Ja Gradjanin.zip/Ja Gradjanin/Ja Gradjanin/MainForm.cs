﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin
{
    public partial class MainForm : Form
    {
        private string NO_PROJECT_SELECTED = @"No project selected.";
        private string ARE_YOU_SURE = @"Are you sure?";
        private string ERROR_OCCURED = @"Error occured";

        public MainForm()
        {   
            InitializeComponent();
            LoadSelectedLanguageStrings();
            refreshProjectsTable(false);

            if (Program.UserController.CurrentUser.FK_VrstaKorisnika_VrstaKorisnikaID != 1)
            {
                tabControl.TabPages.Remove(tabPageAccounts);
            }
            
        }

        private void LoadSelectedLanguageStrings()
        {
            if (Program.LanguageResxSet != null)
            {
                tabPageProjects.Text = Program.LanguageResxSet.GetString("projects");
                tabPageParticipants.Text = Program.LanguageResxSet.GetString("participants");
                tabPageReports.Text = Program.LanguageResxSet.GetString("documents");
                tabPageAccounts.Text = Program.LanguageResxSet.GetString("useraccounts");


                buttonProjectAdd.Text = Program.LanguageResxSet.GetString("add");
                buttonProjectView.Text = Program.LanguageResxSet.GetString("view");
                buttonProjectDelete.Text = Program.LanguageResxSet.GetString("delete");
                buttonProjectRefresh.Text = Program.LanguageResxSet.GetString("refresh");
                columnTitle.HeaderText = Program.LanguageResxSet.GetString("title");
                columnTown.HeaderText = Program.LanguageResxSet.GetString("town");
                columnStartDate.HeaderText = Program.LanguageResxSet.GetString("startdate");
                columnEndDate.HeaderText = Program.LanguageResxSet.GetString("enddate");
                columnBudget.HeaderText = Program.LanguageResxSet.GetString("budget");
                columnPercentage.HeaderText = Program.LanguageResxSet.GetString("progress");
                columnStatus.HeaderText = Program.LanguageResxSet.GetString("status");
                ColumnParticipantRole.HeaderText = Program.LanguageResxSet.GetString("role");
                ColumnParticipantsName.HeaderText = Program.LanguageResxSet.GetString("name");
                ColumnParticipantsSurname.HeaderText = Program.LanguageResxSet.GetString("surname");
                buttonParticipantAdd.Text = Program.LanguageResxSet.GetString("add");
                buttonParticipantEdit.Text = Program.LanguageResxSet.GetString("edit");
                buttonParticipantDelete.Text = Program.LanguageResxSet.GetString("delete");
                buttonParticipantRefresh.Text = Program.LanguageResxSet.GetString("refresh");
                toolStripMenuItemApplication.Text = Program.LanguageResxSet.GetString("application");
                closeToolStripMenuItem.Text = Program.LanguageResxSet.GetString("close");
                helpToolStripMenuItem.Text = Program.LanguageResxSet.GetString("help");
                helpToolStripMenuItem1.Text = Program.LanguageResxSet.GetString("help");
                buttonReportAdd.Text = Program.LanguageResxSet.GetString("add");
                buttonReportDelete.Text = Program.LanguageResxSet.GetString("delete");
                buttonReportsRefresh.Text = Program.LanguageResxSet.GetString("refresh");
                ColumnReportDate.HeaderText = Program.LanguageResxSet.GetString("date");
                ColumnReportCoordinator.HeaderText = Program.LanguageResxSet.GetString("coordinator");
                dataGridViewUsersName.HeaderText = Program.LanguageResxSet.GetString("name");
                dataGridViewUsersSurname.HeaderText = Program.LanguageResxSet.GetString("surname");
                dataGridViewUsersUsername.HeaderText = Program.LanguageResxSet.GetString("username");
                buttonUserAdd.Text = Program.LanguageResxSet.GetString("add");
                buttonUserEdit.Text = Program.LanguageResxSet.GetString("edit");
                buttonUserDelete.Text = Program.LanguageResxSet.GetString("delete");
                buttonUserRefresh.Text = Program.LanguageResxSet.GetString("refresh");

                NO_PROJECT_SELECTED = Program.LanguageResxSet.GetString("noprojectselected");
                ARE_YOU_SURE = Program.LanguageResxSet.GetString("areyousure");
                ERROR_OCCURED = Program.LanguageResxSet.GetString("erroroccured");

                menuStrip1.Invalidate();
            }

        }

        private void TabControlSelectTab(object sender, TabControlEventArgs e)
        {
            if (tabControl.SelectedTab == tabPageProjects)
            {
                refreshProjectsTable(false);
            }
            else if (tabControl.SelectedTab == tabPageParticipants)
            {
                refreshParticipantsTable();
            }
            else if (tabControl.SelectedTab == tabPageAccounts)
            {
                RefreshUsersTable();
            }
            else if (tabControl.SelectedTab == tabPageReports)
            {
                RefreshFileTable();
            }
        }

        private void refreshParticipantsTable()
        {
            dataGridViewParticipants.Rows.Clear();

            List<projekat_ucesnik> participants = Program.ParticipantController.ListParticipants();

            foreach (projekat_ucesnik pu in participants)
            {
                object[] rowData = new object[4];
                rowData[0] = pu.ID;
                rowData[1] = Program.ParticipantController.GetSpecificRoleName(pu.FK_UcesnikProjektaUlogaID, 3).Naziv;
                rowData[2] = pu.Ime;
                rowData[3] = pu.Prezime;
                dataGridViewParticipants.Rows.Add(rowData);
            }
        }


        /// <summary>
        ///  method which fills projects table with data
        /// </summary>
        private void refreshProjectsTable(bool search)
        {
            dataGridViewProjects.Rows.Clear();
            List<projekat> projects = Program.ProjectController.ListProjects(search, textBoxProjectSearch.Text);

            foreach (projekat p in projects)
            {
                object[] rowData = new object[8];
                rowData[0] = p.ID;
                rowData[1] = p.Naziv;
                rowData[2] = Program.TeritoryController.GetTeritory(p.FK_TeritorijalnaJedinica_ID).Naziv;
                rowData[3] = p.DatumPocetka.ToShortDateString();
                rowData[4] = p.DatumZavrsetka.ToShortDateString();
                rowData[5] = p.Budzet;
                rowData[6] = p.ProcenatZavrsenosti.ToString("##%");
                rowData[7] = Program.ProjectController.GetProjekatStatus(p.FK_ProjekatStatusID);
                dataGridViewProjects.Rows.Add(rowData);
            }

            
        }

        private void ButtonProjectRefreshClick(object sender, EventArgs e)
        {
            refreshProjectsTable(false);
        }

        private void buttonProjectDeleteClick(object sender, EventArgs e)
        {
            if (dataGridViewProjects.SelectedRows.Count == 0)
            {
                MessageBox.Show(NO_PROJECT_SELECTED);
            }
            else if (dataGridViewProjects.SelectedRows.Count == 1)
            {
                DialogResult dr = MessageBox.Show(ARE_YOU_SURE, "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.OK)
                {
                    bool result = Program.ProjectController.DeleteProject((int)dataGridViewProjects.SelectedRows[0].Cells[0].Value);
                    if (!result)
                    {
                        MessageBox.Show(ERROR_OCCURED);
                    }
                    refreshProjectsTable(false);
                }
            }
        }

        private void buttonProjectAddClick(object sender, EventArgs e)
        {
            ShowProjectEditForm(1);
        }

        private void ShowProjectEditForm(int mode)
        {
            ProjectEditForm pef = new ProjectEditForm();

            if (mode == 2)
            {
                pef = new ProjectEditForm(Program.ProjectController.GetProject((int)dataGridViewProjects.SelectedRows[0].Cells[0].Value));
            }

            pef.ShowDialog();

            refreshProjectsTable(false);
        }

        private void buttonProjectViewClick(object sender, EventArgs e)
        {
            ShowProjectEditForm(2);
        }

        private void ShowParticipantEditForm(int mode)
        {
            ParticipantEditForm pef = null;

            if (mode == 1)
            {
                pef = new ParticipantEditForm();
                pef.ShowDialog();
                refreshParticipantsTable();
            }
            else if (mode == 2)
            {
                pef = new ParticipantEditForm((int)dataGridViewParticipants.SelectedRows[0].Cells[0].Value);
                pef.ShowDialog();
                refreshParticipantsTable();
            }
        }

        private void buttonParticipantAddClick(object sender, EventArgs e)
        {
            ShowParticipantEditForm(1);
            refreshParticipantsTable();
        }

        private void buttonParticipantRefreshClick(object sender, EventArgs e)
        {
            refreshParticipantsTable();
        }

        private void buttonParticipantDeleteClick(object sender, EventArgs e)
        {
            if (dataGridViewParticipants.SelectedRows.Count > 0)
            {
                Program.ParticipantController.DeleteParticipant( (int)dataGridViewParticipants.SelectedRows[0].Cells[0].Value);
                refreshParticipantsTable();
            }
        }

        private void buttonParticipantEditClicked(object sender, EventArgs e)
        {
            ShowParticipantEditForm(2);
        }

        private void helpToolStripMenuItem1Clicked(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"Help\Upustvo_za_koristenje_softvera.pdf");
        }

        private void closeToolStripMenuItemClicked(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonUserDeleteClick(object sender, EventArgs e)
        {
            if (dataGridViewUsers.SelectedRows.Count > 0)
            {
                Program.UserController.DeleteUser((int)dataGridViewUsers.SelectedRows[0].Cells[0].Value);
                RefreshUsersTable();
            }
            
        }

        private void buttonUserAddClick(object sender, EventArgs e)
        {
            ShowUserEditForm(1);
        }

        private void buttonUserEditClick(object sender, EventArgs e)
        {
            ShowUserEditForm(2);
        }

        /// <summary>
        /// mode = 1 => new
        /// mode = 2 => edit
        /// </summary>
        /// <param name="mode"></param>
        private void ShowUserEditForm(int mode)
        {
            if (mode == 1)
            {
                UserEditForm uef = new UserEditForm();
                uef.ShowDialog();
            }
            else if (mode == 2)
            {
                UserEditForm uef = new UserEditForm( ((int)dataGridViewUsers.SelectedRows[0].Cells[0].Value) );
                uef.ShowDialog();
            }

            RefreshUsersTable();
        }

        private void buttonUserRefreshClick(object sender, EventArgs e)
        {
            RefreshUsersTable();
        }

        private void RefreshUsersTable()
        {
            dataGridViewUsers.Rows.Clear();

            List<korisnik> users = Program.UserController.ListAllUsers();

            foreach (korisnik k in users)
            {
                object[] rowdata = new object[5];
                rowdata[0] = k.ID;
                rowdata[1] = k.Ime;
                rowdata[2] = k.Prezime;
                rowdata[3] = k.KorisnickoIme;
                dataGridViewUsers.Rows.Add(rowdata);
            }
        }

        private void RefreshFileTable()
        {
            dataGridViewReports.Rows.Clear();

            List<izvjestaj> files = Program.DocumentController.GetDocumentsList();

            foreach (izvjestaj i in files)
            {
                object[] rowdata = new object[5];
                rowdata[0] = i.ID;
                rowdata[2] = i.FileName;
                rowdata[3] = i.DatumKreiranja;
                rowdata[4] = Program.UserController.GetUserByID(i.FK_Korisnik_ID).KorisnickoIme;
                dataGridViewReports.Rows.Add(rowdata);
            }

        }

        private void buttonReportAddClick(object sender, EventArgs e)
        {

            FileAdd();
            RefreshFileTable();
        }

        private void buttonReportDeleteClick(object sender, EventArgs e)
        {
            Program.DocumentController.DeleteFile((int)dataGridViewReports.SelectedRows[0].Cells[0].Value);
            RefreshFileTable();
        }

        private void buttonReportRefreshClick(object sender, EventArgs e)
        {
            RefreshFileTable();
        }

        private void FileAdd()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "(Documents)|*.doc;*.docx;*.pdf;*.xls;*.xlsx;*.ppt;*.pptx|(All files)|*.*";

            if (DialogResult.OK == ofd.ShowDialog())
            {
                try
                {
                    FileStream fs = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read);
                    byte[] file = new byte[fs.Length];
                    fs.Read(file, 0, file.Length);
                    Program.DocumentController.SaveFile(file, ofd.SafeFileName);
                    fs.Close();
                }
                catch (IOException i)
                {

                }
            }
        }

        private void buttonReportDownload_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.FileName = (string)dataGridViewReports.SelectedRows[0].Cells[2].Value;
            byte[] file = Program.DocumentController.LoadFile( (int)dataGridViewReports.SelectedRows[0].Cells[0].Value).File;
            sfd.ShowDialog();
            try
            {
                FileStream fs = (FileStream)sfd.OpenFile();
                fs.Write(file, 0, file.Length);
                fs.Flush();
                fs.Close();
            }
            catch
            {

            }
            
        }

        private void buttonProjectSearchReset_Click(object sender, EventArgs e)
        {
            textBoxProjectSearch.Text = "";
            refreshProjectsTable(false);
        }

        private void buttonProjectSearch_Click(object sender, EventArgs e)
        {
            if (textBoxProjectSearch.Text != "")
            {
                refreshProjectsTable(true);
            }
            else
            {
                refreshProjectsTable(false);
            }
        }

    }
}
