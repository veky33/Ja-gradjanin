﻿namespace Ja_Gradjanin
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItemApplication = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPageProjects = new System.Windows.Forms.TabPage();
            this.buttonProjectSearchReset = new System.Windows.Forms.Button();
            this.buttonProjectSearch = new System.Windows.Forms.Button();
            this.textBoxProjectSearch = new System.Windows.Forms.TextBox();
            this.dataGridViewProjects = new System.Windows.Forms.DataGridView();
            this.columnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnTown = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnStartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnEndDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnBudget = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnPercentage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonProjectRefresh = new System.Windows.Forms.Button();
            this.buttonProjectDelete = new System.Windows.Forms.Button();
            this.buttonProjectView = new System.Windows.Forms.Button();
            this.buttonProjectAdd = new System.Windows.Forms.Button();
            this.tabPageParticipants = new System.Windows.Forms.TabPage();
            this.buttonParticipantRefresh = new System.Windows.Forms.Button();
            this.buttonParticipantDelete = new System.Windows.Forms.Button();
            this.buttonParticipantEdit = new System.Windows.Forms.Button();
            this.buttonParticipantAdd = new System.Windows.Forms.Button();
            this.dataGridViewParticipants = new System.Windows.Forms.DataGridView();
            this.ColumnParticipantID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnParticipantRole = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnParticipantsName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnParticipantsSurname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageReports = new System.Windows.Forms.TabPage();
            this.buttonReportDownload = new System.Windows.Forms.Button();
            this.buttonReportsRefresh = new System.Windows.Forms.Button();
            this.buttonReportDelete = new System.Windows.Forms.Button();
            this.buttonReportAdd = new System.Windows.Forms.Button();
            this.dataGridViewReports = new System.Windows.Forms.DataGridView();
            this.ColumnReportsID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReportProjectName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReportDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnReportCoordinator = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageAccounts = new System.Windows.Forms.TabPage();
            this.buttonUserRefresh = new System.Windows.Forms.Button();
            this.buttonUserDelete = new System.Windows.Forms.Button();
            this.buttonUserEdit = new System.Windows.Forms.Button();
            this.buttonUserAdd = new System.Windows.Forms.Button();
            this.dataGridViewUsers = new System.Windows.Forms.DataGridView();
            this.dataGridViewUsersID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewUsersName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewUsersSurname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewUsersUsername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabPageProjects.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProjects)).BeginInit();
            this.tabPageParticipants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewParticipants)).BeginInit();
            this.tabPageReports.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReports)).BeginInit();
            this.tabPageAccounts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemApplication,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1159, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItemApplication
            // 
            this.toolStripMenuItemApplication.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem});
            this.toolStripMenuItemApplication.Name = "toolStripMenuItemApplication";
            this.toolStripMenuItemApplication.Size = new System.Drawing.Size(80, 20);
            this.toolStripMenuItemApplication.Text = "Application";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItemClicked);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem1});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(118, 22);
            this.helpToolStripMenuItem1.Text = "Help";
            this.helpToolStripMenuItem1.Click += new System.EventHandler(this.helpToolStripMenuItem1Clicked);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 512);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1159, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPageProjects);
            this.tabControl.Controls.Add(this.tabPageParticipants);
            this.tabControl.Controls.Add(this.tabPageReports);
            this.tabControl.Controls.Add(this.tabPageAccounts);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.ItemSize = new System.Drawing.Size(50, 25);
            this.tabControl.Location = new System.Drawing.Point(0, 24);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1159, 488);
            this.tabControl.TabIndex = 2;
            this.tabControl.Selected += new System.Windows.Forms.TabControlEventHandler(this.TabControlSelectTab);
            // 
            // tabPageProjects
            // 
            this.tabPageProjects.Controls.Add(this.buttonProjectSearchReset);
            this.tabPageProjects.Controls.Add(this.buttonProjectSearch);
            this.tabPageProjects.Controls.Add(this.textBoxProjectSearch);
            this.tabPageProjects.Controls.Add(this.dataGridViewProjects);
            this.tabPageProjects.Controls.Add(this.buttonProjectRefresh);
            this.tabPageProjects.Controls.Add(this.buttonProjectDelete);
            this.tabPageProjects.Controls.Add(this.buttonProjectView);
            this.tabPageProjects.Controls.Add(this.buttonProjectAdd);
            this.tabPageProjects.Location = new System.Drawing.Point(4, 29);
            this.tabPageProjects.Name = "tabPageProjects";
            this.tabPageProjects.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageProjects.Size = new System.Drawing.Size(1151, 455);
            this.tabPageProjects.TabIndex = 0;
            this.tabPageProjects.Text = "Projects";
            this.tabPageProjects.UseVisualStyleBackColor = true;
            // 
            // buttonProjectSearchReset
            // 
            this.buttonProjectSearchReset.Location = new System.Drawing.Point(697, 19);
            this.buttonProjectSearchReset.Name = "buttonProjectSearchReset";
            this.buttonProjectSearchReset.Size = new System.Drawing.Size(26, 21);
            this.buttonProjectSearchReset.TabIndex = 7;
            this.buttonProjectSearchReset.Text = "X";
            this.buttonProjectSearchReset.UseVisualStyleBackColor = true;
            this.buttonProjectSearchReset.Click += new System.EventHandler(this.buttonProjectSearchReset_Click);
            // 
            // buttonProjectSearch
            // 
            this.buttonProjectSearch.Location = new System.Drawing.Point(643, 19);
            this.buttonProjectSearch.Name = "buttonProjectSearch";
            this.buttonProjectSearch.Size = new System.Drawing.Size(48, 21);
            this.buttonProjectSearch.TabIndex = 6;
            this.buttonProjectSearch.Text = "Traži";
            this.buttonProjectSearch.UseVisualStyleBackColor = true;
            this.buttonProjectSearch.Click += new System.EventHandler(this.buttonProjectSearch_Click);
            // 
            // textBoxProjectSearch
            // 
            this.textBoxProjectSearch.Location = new System.Drawing.Point(536, 19);
            this.textBoxProjectSearch.Name = "textBoxProjectSearch";
            this.textBoxProjectSearch.Size = new System.Drawing.Size(100, 20);
            this.textBoxProjectSearch.TabIndex = 5;
            // 
            // dataGridViewProjects
            // 
            this.dataGridViewProjects.AllowUserToAddRows = false;
            this.dataGridViewProjects.AllowUserToDeleteRows = false;
            this.dataGridViewProjects.AllowUserToOrderColumns = true;
            this.dataGridViewProjects.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewProjects.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewProjects.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewProjects.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.columnID,
            this.columnTitle,
            this.columnTown,
            this.columnStartDate,
            this.columnEndDate,
            this.columnBudget,
            this.columnPercentage,
            this.columnStatus});
            this.dataGridViewProjects.Location = new System.Drawing.Point(8, 59);
            this.dataGridViewProjects.MultiSelect = false;
            this.dataGridViewProjects.Name = "dataGridViewProjects";
            this.dataGridViewProjects.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewProjects.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewProjects.RowHeadersVisible = false;
            this.dataGridViewProjects.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridViewProjects.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewProjects.Size = new System.Drawing.Size(1135, 390);
            this.dataGridViewProjects.TabIndex = 4;
            // 
            // columnID
            // 
            this.columnID.HeaderText = "Column ID";
            this.columnID.MinimumWidth = 2;
            this.columnID.Name = "columnID";
            this.columnID.ReadOnly = true;
            this.columnID.Visible = false;
            // 
            // columnTitle
            // 
            this.columnTitle.HeaderText = "Title";
            this.columnTitle.Name = "columnTitle";
            this.columnTitle.ReadOnly = true;
            // 
            // columnTown
            // 
            this.columnTown.HeaderText = "Town";
            this.columnTown.Name = "columnTown";
            this.columnTown.ReadOnly = true;
            // 
            // columnStartDate
            // 
            this.columnStartDate.HeaderText = "Start Date";
            this.columnStartDate.Name = "columnStartDate";
            this.columnStartDate.ReadOnly = true;
            // 
            // columnEndDate
            // 
            this.columnEndDate.HeaderText = "End Date";
            this.columnEndDate.Name = "columnEndDate";
            this.columnEndDate.ReadOnly = true;
            // 
            // columnBudget
            // 
            this.columnBudget.HeaderText = "Budget";
            this.columnBudget.Name = "columnBudget";
            this.columnBudget.ReadOnly = true;
            // 
            // columnPercentage
            // 
            this.columnPercentage.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.columnPercentage.DefaultCellStyle = dataGridViewCellStyle1;
            this.columnPercentage.HeaderText = "Percentage completed";
            this.columnPercentage.Name = "columnPercentage";
            this.columnPercentage.ReadOnly = true;
            this.columnPercentage.Width = 139;
            // 
            // columnStatus
            // 
            this.columnStatus.HeaderText = "Status";
            this.columnStatus.Name = "columnStatus";
            this.columnStatus.ReadOnly = true;
            // 
            // buttonProjectRefresh
            // 
            this.buttonProjectRefresh.Location = new System.Drawing.Point(380, 17);
            this.buttonProjectRefresh.Name = "buttonProjectRefresh";
            this.buttonProjectRefresh.Size = new System.Drawing.Size(75, 23);
            this.buttonProjectRefresh.TabIndex = 3;
            this.buttonProjectRefresh.Text = "Refresh";
            this.buttonProjectRefresh.UseVisualStyleBackColor = true;
            this.buttonProjectRefresh.Click += new System.EventHandler(this.ButtonProjectRefreshClick);
            // 
            // buttonProjectDelete
            // 
            this.buttonProjectDelete.Location = new System.Drawing.Point(171, 17);
            this.buttonProjectDelete.Name = "buttonProjectDelete";
            this.buttonProjectDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonProjectDelete.TabIndex = 2;
            this.buttonProjectDelete.Text = "Delete";
            this.buttonProjectDelete.UseVisualStyleBackColor = true;
            this.buttonProjectDelete.Click += new System.EventHandler(this.buttonProjectDeleteClick);
            // 
            // buttonProjectView
            // 
            this.buttonProjectView.Location = new System.Drawing.Point(90, 17);
            this.buttonProjectView.Name = "buttonProjectView";
            this.buttonProjectView.Size = new System.Drawing.Size(75, 23);
            this.buttonProjectView.TabIndex = 1;
            this.buttonProjectView.Text = "View";
            this.buttonProjectView.UseVisualStyleBackColor = true;
            this.buttonProjectView.Click += new System.EventHandler(this.buttonProjectViewClick);
            // 
            // buttonProjectAdd
            // 
            this.buttonProjectAdd.Location = new System.Drawing.Point(8, 17);
            this.buttonProjectAdd.Name = "buttonProjectAdd";
            this.buttonProjectAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonProjectAdd.TabIndex = 0;
            this.buttonProjectAdd.Text = "Add";
            this.buttonProjectAdd.UseVisualStyleBackColor = true;
            this.buttonProjectAdd.Click += new System.EventHandler(this.buttonProjectAddClick);
            // 
            // tabPageParticipants
            // 
            this.tabPageParticipants.Controls.Add(this.buttonParticipantRefresh);
            this.tabPageParticipants.Controls.Add(this.buttonParticipantDelete);
            this.tabPageParticipants.Controls.Add(this.buttonParticipantEdit);
            this.tabPageParticipants.Controls.Add(this.buttonParticipantAdd);
            this.tabPageParticipants.Controls.Add(this.dataGridViewParticipants);
            this.tabPageParticipants.Location = new System.Drawing.Point(4, 29);
            this.tabPageParticipants.Name = "tabPageParticipants";
            this.tabPageParticipants.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageParticipants.Size = new System.Drawing.Size(1151, 455);
            this.tabPageParticipants.TabIndex = 1;
            this.tabPageParticipants.Text = "Participants";
            this.tabPageParticipants.UseVisualStyleBackColor = true;
            // 
            // buttonParticipantRefresh
            // 
            this.buttonParticipantRefresh.Location = new System.Drawing.Point(380, 17);
            this.buttonParticipantRefresh.Name = "buttonParticipantRefresh";
            this.buttonParticipantRefresh.Size = new System.Drawing.Size(75, 23);
            this.buttonParticipantRefresh.TabIndex = 7;
            this.buttonParticipantRefresh.Text = "Refresh";
            this.buttonParticipantRefresh.UseVisualStyleBackColor = true;
            this.buttonParticipantRefresh.Click += new System.EventHandler(this.buttonParticipantRefreshClick);
            // 
            // buttonParticipantDelete
            // 
            this.buttonParticipantDelete.Location = new System.Drawing.Point(171, 17);
            this.buttonParticipantDelete.Name = "buttonParticipantDelete";
            this.buttonParticipantDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonParticipantDelete.TabIndex = 6;
            this.buttonParticipantDelete.Text = "Delete";
            this.buttonParticipantDelete.UseVisualStyleBackColor = true;
            this.buttonParticipantDelete.Visible = false;
            this.buttonParticipantDelete.Click += new System.EventHandler(this.buttonParticipantDeleteClick);
            // 
            // buttonParticipantEdit
            // 
            this.buttonParticipantEdit.Location = new System.Drawing.Point(90, 17);
            this.buttonParticipantEdit.Name = "buttonParticipantEdit";
            this.buttonParticipantEdit.Size = new System.Drawing.Size(75, 23);
            this.buttonParticipantEdit.TabIndex = 5;
            this.buttonParticipantEdit.Text = "Edit";
            this.buttonParticipantEdit.UseVisualStyleBackColor = true;
            this.buttonParticipantEdit.Click += new System.EventHandler(this.buttonParticipantEditClicked);
            // 
            // buttonParticipantAdd
            // 
            this.buttonParticipantAdd.Location = new System.Drawing.Point(8, 17);
            this.buttonParticipantAdd.Name = "buttonParticipantAdd";
            this.buttonParticipantAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonParticipantAdd.TabIndex = 4;
            this.buttonParticipantAdd.Text = "Add";
            this.buttonParticipantAdd.UseVisualStyleBackColor = true;
            this.buttonParticipantAdd.Click += new System.EventHandler(this.buttonParticipantAddClick);
            // 
            // dataGridViewParticipants
            // 
            this.dataGridViewParticipants.AllowUserToAddRows = false;
            this.dataGridViewParticipants.AllowUserToDeleteRows = false;
            this.dataGridViewParticipants.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewParticipants.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewParticipants.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewParticipants.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnParticipantID,
            this.ColumnParticipantRole,
            this.ColumnParticipantsName,
            this.ColumnParticipantsSurname});
            this.dataGridViewParticipants.Location = new System.Drawing.Point(8, 59);
            this.dataGridViewParticipants.MultiSelect = false;
            this.dataGridViewParticipants.Name = "dataGridViewParticipants";
            this.dataGridViewParticipants.ReadOnly = true;
            this.dataGridViewParticipants.RowHeadersVisible = false;
            this.dataGridViewParticipants.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewParticipants.Size = new System.Drawing.Size(1143, 396);
            this.dataGridViewParticipants.TabIndex = 0;
            // 
            // ColumnParticipantID
            // 
            this.ColumnParticipantID.HeaderText = "ID";
            this.ColumnParticipantID.Name = "ColumnParticipantID";
            this.ColumnParticipantID.ReadOnly = true;
            this.ColumnParticipantID.Visible = false;
            // 
            // ColumnParticipantRole
            // 
            this.ColumnParticipantRole.HeaderText = "Role";
            this.ColumnParticipantRole.Name = "ColumnParticipantRole";
            this.ColumnParticipantRole.ReadOnly = true;
            // 
            // ColumnParticipantsName
            // 
            this.ColumnParticipantsName.HeaderText = "Name";
            this.ColumnParticipantsName.Name = "ColumnParticipantsName";
            this.ColumnParticipantsName.ReadOnly = true;
            // 
            // ColumnParticipantsSurname
            // 
            this.ColumnParticipantsSurname.HeaderText = "Surname";
            this.ColumnParticipantsSurname.Name = "ColumnParticipantsSurname";
            this.ColumnParticipantsSurname.ReadOnly = true;
            // 
            // tabPageReports
            // 
            this.tabPageReports.Controls.Add(this.buttonReportDownload);
            this.tabPageReports.Controls.Add(this.buttonReportsRefresh);
            this.tabPageReports.Controls.Add(this.buttonReportDelete);
            this.tabPageReports.Controls.Add(this.buttonReportAdd);
            this.tabPageReports.Controls.Add(this.dataGridViewReports);
            this.tabPageReports.Location = new System.Drawing.Point(4, 29);
            this.tabPageReports.Name = "tabPageReports";
            this.tabPageReports.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageReports.Size = new System.Drawing.Size(1151, 455);
            this.tabPageReports.TabIndex = 3;
            this.tabPageReports.Text = "Documents";
            this.tabPageReports.UseVisualStyleBackColor = true;
            // 
            // buttonReportDownload
            // 
            this.buttonReportDownload.Location = new System.Drawing.Point(90, 17);
            this.buttonReportDownload.Name = "buttonReportDownload";
            this.buttonReportDownload.Size = new System.Drawing.Size(75, 23);
            this.buttonReportDownload.TabIndex = 11;
            this.buttonReportDownload.Text = "Preuzmi";
            this.buttonReportDownload.UseVisualStyleBackColor = true;
            this.buttonReportDownload.Click += new System.EventHandler(this.buttonReportDownload_Click);
            // 
            // buttonReportsRefresh
            // 
            this.buttonReportsRefresh.Location = new System.Drawing.Point(380, 17);
            this.buttonReportsRefresh.Name = "buttonReportsRefresh";
            this.buttonReportsRefresh.Size = new System.Drawing.Size(75, 23);
            this.buttonReportsRefresh.TabIndex = 10;
            this.buttonReportsRefresh.Text = "Refresh";
            this.buttonReportsRefresh.UseVisualStyleBackColor = true;
            this.buttonReportsRefresh.Click += new System.EventHandler(this.buttonReportRefreshClick);
            // 
            // buttonReportDelete
            // 
            this.buttonReportDelete.Location = new System.Drawing.Point(171, 17);
            this.buttonReportDelete.Name = "buttonReportDelete";
            this.buttonReportDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonReportDelete.TabIndex = 9;
            this.buttonReportDelete.Text = "Delete";
            this.buttonReportDelete.UseVisualStyleBackColor = true;
            this.buttonReportDelete.Click += new System.EventHandler(this.buttonReportDeleteClick);
            // 
            // buttonReportAdd
            // 
            this.buttonReportAdd.Location = new System.Drawing.Point(8, 17);
            this.buttonReportAdd.Name = "buttonReportAdd";
            this.buttonReportAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonReportAdd.TabIndex = 8;
            this.buttonReportAdd.Text = "Add";
            this.buttonReportAdd.UseVisualStyleBackColor = true;
            this.buttonReportAdd.Click += new System.EventHandler(this.buttonReportAddClick);
            // 
            // dataGridViewReports
            // 
            this.dataGridViewReports.AllowUserToAddRows = false;
            this.dataGridViewReports.AllowUserToDeleteRows = false;
            this.dataGridViewReports.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewReports.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewReports.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnReportsID,
            this.ColumnReportProjectName,
            this.ColumnName,
            this.ColumnReportDate,
            this.ColumnReportCoordinator});
            this.dataGridViewReports.Location = new System.Drawing.Point(8, 59);
            this.dataGridViewReports.MultiSelect = false;
            this.dataGridViewReports.Name = "dataGridViewReports";
            this.dataGridViewReports.ReadOnly = true;
            this.dataGridViewReports.RowHeadersVisible = false;
            this.dataGridViewReports.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewReports.Size = new System.Drawing.Size(1159, 488);
            this.dataGridViewReports.TabIndex = 0;
            // 
            // ColumnReportsID
            // 
            this.ColumnReportsID.HeaderText = "ID";
            this.ColumnReportsID.Name = "ColumnReportsID";
            this.ColumnReportsID.ReadOnly = true;
            this.ColumnReportsID.Visible = false;
            // 
            // ColumnReportProjectName
            // 
            this.ColumnReportProjectName.HeaderText = "Project";
            this.ColumnReportProjectName.Name = "ColumnReportProjectName";
            this.ColumnReportProjectName.ReadOnly = true;
            this.ColumnReportProjectName.Visible = false;
            // 
            // ColumnName
            // 
            this.ColumnName.HeaderText = "Naziv";
            this.ColumnName.Name = "ColumnName";
            this.ColumnName.ReadOnly = true;
            // 
            // ColumnReportDate
            // 
            this.ColumnReportDate.HeaderText = "Date";
            this.ColumnReportDate.Name = "ColumnReportDate";
            this.ColumnReportDate.ReadOnly = true;
            // 
            // ColumnReportCoordinator
            // 
            this.ColumnReportCoordinator.HeaderText = "Coordinator";
            this.ColumnReportCoordinator.Name = "ColumnReportCoordinator";
            this.ColumnReportCoordinator.ReadOnly = true;
            // 
            // tabPageAccounts
            // 
            this.tabPageAccounts.Controls.Add(this.buttonUserRefresh);
            this.tabPageAccounts.Controls.Add(this.buttonUserDelete);
            this.tabPageAccounts.Controls.Add(this.buttonUserEdit);
            this.tabPageAccounts.Controls.Add(this.buttonUserAdd);
            this.tabPageAccounts.Controls.Add(this.dataGridViewUsers);
            this.tabPageAccounts.Location = new System.Drawing.Point(4, 29);
            this.tabPageAccounts.Name = "tabPageAccounts";
            this.tabPageAccounts.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAccounts.Size = new System.Drawing.Size(1151, 455);
            this.tabPageAccounts.TabIndex = 2;
            this.tabPageAccounts.Text = "User accounts";
            this.tabPageAccounts.UseVisualStyleBackColor = true;
            // 
            // buttonUserRefresh
            // 
            this.buttonUserRefresh.Location = new System.Drawing.Point(376, 17);
            this.buttonUserRefresh.Name = "buttonUserRefresh";
            this.buttonUserRefresh.Size = new System.Drawing.Size(75, 23);
            this.buttonUserRefresh.TabIndex = 12;
            this.buttonUserRefresh.Text = "Refresh";
            this.buttonUserRefresh.UseVisualStyleBackColor = true;
            this.buttonUserRefresh.Click += new System.EventHandler(this.buttonUserRefreshClick);
            // 
            // buttonUserDelete
            // 
            this.buttonUserDelete.Location = new System.Drawing.Point(167, 17);
            this.buttonUserDelete.Name = "buttonUserDelete";
            this.buttonUserDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonUserDelete.TabIndex = 11;
            this.buttonUserDelete.Text = "Delete";
            this.buttonUserDelete.UseVisualStyleBackColor = true;
            this.buttonUserDelete.Click += new System.EventHandler(this.buttonUserDeleteClick);
            // 
            // buttonUserEdit
            // 
            this.buttonUserEdit.Location = new System.Drawing.Point(86, 17);
            this.buttonUserEdit.Name = "buttonUserEdit";
            this.buttonUserEdit.Size = new System.Drawing.Size(75, 23);
            this.buttonUserEdit.TabIndex = 10;
            this.buttonUserEdit.Text = "Edit";
            this.buttonUserEdit.UseVisualStyleBackColor = true;
            this.buttonUserEdit.Click += new System.EventHandler(this.buttonUserEditClick);
            // 
            // buttonUserAdd
            // 
            this.buttonUserAdd.Location = new System.Drawing.Point(8, 17);
            this.buttonUserAdd.Name = "buttonUserAdd";
            this.buttonUserAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonUserAdd.TabIndex = 9;
            this.buttonUserAdd.Text = "Add";
            this.buttonUserAdd.UseVisualStyleBackColor = true;
            this.buttonUserAdd.Click += new System.EventHandler(this.buttonUserAddClick);
            // 
            // dataGridViewUsers
            // 
            this.dataGridViewUsers.AllowUserToAddRows = false;
            this.dataGridViewUsers.AllowUserToDeleteRows = false;
            this.dataGridViewUsers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewUsers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUsers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewUsersID,
            this.dataGridViewUsersName,
            this.dataGridViewUsersSurname,
            this.dataGridViewUsersUsername});
            this.dataGridViewUsers.Location = new System.Drawing.Point(8, 59);
            this.dataGridViewUsers.MultiSelect = false;
            this.dataGridViewUsers.Name = "dataGridViewUsers";
            this.dataGridViewUsers.ReadOnly = true;
            this.dataGridViewUsers.RowHeadersVisible = false;
            this.dataGridViewUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewUsers.Size = new System.Drawing.Size(1143, 396);
            this.dataGridViewUsers.TabIndex = 8;
            // 
            // dataGridViewUsersID
            // 
            this.dataGridViewUsersID.HeaderText = "ID";
            this.dataGridViewUsersID.Name = "dataGridViewUsersID";
            this.dataGridViewUsersID.ReadOnly = true;
            this.dataGridViewUsersID.Visible = false;
            // 
            // dataGridViewUsersName
            // 
            this.dataGridViewUsersName.HeaderText = "Name";
            this.dataGridViewUsersName.Name = "dataGridViewUsersName";
            this.dataGridViewUsersName.ReadOnly = true;
            // 
            // dataGridViewUsersSurname
            // 
            this.dataGridViewUsersSurname.HeaderText = "Surname";
            this.dataGridViewUsersSurname.Name = "dataGridViewUsersSurname";
            this.dataGridViewUsersSurname.ReadOnly = true;
            // 
            // dataGridViewUsersUsername
            // 
            this.dataGridViewUsersUsername.HeaderText = "Username";
            this.dataGridViewUsersUsername.Name = "dataGridViewUsersUsername";
            this.dataGridViewUsersUsername.ReadOnly = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1159, 534);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CIVITAS - Ja građanin";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.tabPageProjects.ResumeLayout(false);
            this.tabPageProjects.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProjects)).EndInit();
            this.tabPageParticipants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewParticipants)).EndInit();
            this.tabPageReports.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReports)).EndInit();
            this.tabPageAccounts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemApplication;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPageProjects;
        private System.Windows.Forms.Button buttonProjectRefresh;
        private System.Windows.Forms.Button buttonProjectDelete;
        private System.Windows.Forms.Button buttonProjectView;
        private System.Windows.Forms.Button buttonProjectAdd;
        private System.Windows.Forms.TabPage tabPageParticipants;
        private System.Windows.Forms.TabPage tabPageAccounts;
        private System.Windows.Forms.TabPage tabPageReports;
        private System.Windows.Forms.DataGridView dataGridViewProjects;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnTown;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnStartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnEndDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnBudget;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnPercentage;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnStatus;
        private System.Windows.Forms.Button buttonParticipantRefresh;
        private System.Windows.Forms.Button buttonParticipantDelete;
        private System.Windows.Forms.Button buttonParticipantEdit;
        private System.Windows.Forms.Button buttonParticipantAdd;
        private System.Windows.Forms.DataGridView dataGridViewParticipants;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnParticipantID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnParticipantRole;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnParticipantsName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnParticipantsSurname;
        private System.Windows.Forms.Button buttonReportsRefresh;
        private System.Windows.Forms.Button buttonReportDelete;
        private System.Windows.Forms.Button buttonReportAdd;
        private System.Windows.Forms.DataGridView dataGridViewReports;
        private System.Windows.Forms.Button buttonUserRefresh;
        private System.Windows.Forms.Button buttonUserDelete;
        private System.Windows.Forms.Button buttonUserEdit;
        private System.Windows.Forms.Button buttonUserAdd;
        private System.Windows.Forms.DataGridView dataGridViewUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewUsersID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewUsersName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewUsersSurname;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewUsersUsername;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReportsID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReportProjectName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReportDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReportCoordinator;
        private System.Windows.Forms.Button buttonReportDownload;
        private System.Windows.Forms.Button buttonProjectSearchReset;
        private System.Windows.Forms.Button buttonProjectSearch;
        private System.Windows.Forms.TextBox textBoxProjectSearch;
    }
}