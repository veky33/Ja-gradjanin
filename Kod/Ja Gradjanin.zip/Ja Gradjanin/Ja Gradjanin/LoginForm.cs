﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Windows.Forms;

namespace Ja_Gradjanin
{
    public partial class LoginForm : Form
    {
        private string loginError = @"Username or password is incorrect";


        public LoginForm()
        {
            InitializeComponent();
            LoadSelectedLanguageStrings();
        }

        private void buttonLoginClick(object sender, EventArgs e)
        {
            if (!Program.UserController.VerifyLogin(textBoxUsername.Text, textBoxPassword.Text))
            {
                MessageBox.Show(loginError);
            }
            else
            {
                this.Hide();
                Form form = new MainForm();
                form.ShowDialog();
                this.Close();
            }
        }

        private void buttonExitClick(object sender, EventArgs e)
        {
            this.Close(); // exit from application when clicked on buttonExit
        }

        /// <summary>
        /// Method for loading language resource file and localizing text in LoginForm 
        /// </summary>
        /// <param name="languageCode"></param>
        private void LoadSelectedLanguageStrings()
        {
            if (Program.LanguageResxSet != null)
            {
                labelUsername.Text = Program.LanguageResxSet.GetString("username");
                labelPassword.Text = Program.LanguageResxSet.GetString("password");
                buttonExit.Text = Program.LanguageResxSet.GetString("close");
                buttonLogin.Text = Program.LanguageResxSet.GetString("login");
                this.loginError = Program.LanguageResxSet.GetString("incorrectlogincredentials");
            }

        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void OnEnterPress(object sender, KeyPressEventArgs e)
        {

        }
    }
}
