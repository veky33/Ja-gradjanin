﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin
{
    public partial class FinancesForm : Form
    {
        int projectID;
        int type; // type = 1 income, type = 2 expenditure
        int mode; // 1 - new , 2 - editing
        prihod income;
        rashod expenditure;

        string TYPED_DATA_NOT_VALID = "TYPED_DATA_NOT_VALID";

        private FinancesForm()
        {
            InitializeComponent();
            LoadLanguagesStrings();

        }

        // type = 1 income, type = 2 expenditure

        public FinancesForm(int projectID, int type) : this()
        {
            this.projectID = projectID;
            this.type = type;
            this.mode = 1;
            if (type == 2)
            {
                labelFinancier.Visible = false;
                textBoxFinancier.Visible = false;
            }
        }

        public FinancesForm(int projectID, int type, int financeID) : this(projectID,type)
        {
            //this.projectID = projectID;
            //this.type = type;
            this.mode = 2;

            if (type == 1)
            {
                income = Program.FinanceController.GetSpecificIncome(financeID);

                dateTimePicker.Value = income.Datum.Date;
                textBoxDescription.Text = income.Opis;
                numericUpDown.Value = income.NovcaniIznos;
                textBoxFinancier.Text = income.FinansiranOd;
            }
            else if (type == 2)
            {
                expenditure = Program.FinanceController.GetSpecificExpenditure(financeID);
                dateTimePicker.Value = expenditure.Datum.Date;
                textBoxDescription.Text = expenditure.Opis;
                numericUpDown.Value = expenditure.NovcaniIznos;

            }
        }





        private void LoadLanguagesStrings()
        {
            labelDate.Text = Program.LanguageResxSet.GetString("date");
            labelDescription.Text = Program.LanguageResxSet.GetString("description");
            labelAmount.Text = Program.LanguageResxSet.GetString("amount");
            labelFinancier.Text = Program.LanguageResxSet.GetString("financedfrom");
            buttonCancel.Text = Program.LanguageResxSet.GetString("cancel");
            buttonSave.Text = Program.LanguageResxSet.GetString("save");

            TYPED_DATA_NOT_VALID = Program.LanguageResxSet.GetString("typeddatanotvalid");
        }

        private void buttonCancelClicked(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonSaveClicked(object sender, EventArgs e)
        {
            if (type == 1)
            {
                if (textBoxDescription.Text != "" && numericUpDown.Value > (decimal)0.0 && textBoxFinancier.Text != "" )
                {
                    SaveFinance();
                }
                else
                {
                    MessageBox.Show(TYPED_DATA_NOT_VALID);
                }
            }
            else if (type == 2)
            {
                if (textBoxDescription.Text != "" && numericUpDown.Value > (decimal)0.0)
                {
                    SaveFinance();
                }
                else
                {
                    MessageBox.Show(TYPED_DATA_NOT_VALID);
                }
            }
            
        }

        private void SaveFinance()
        {
            if (type == 1)
            {
                if (mode == 1)
                {
                    Program.FinanceController.CreateIncome(textBoxDescription.Text, numericUpDown.Value, textBoxFinancier.Text, dateTimePicker.Value.Date, projectID);
                }
                else if (mode == 2)
                {
                    Program.FinanceController.UpdateIncome(income.ID, textBoxDescription.Text, numericUpDown.Value, textBoxFinancier.Text, dateTimePicker.Value.Date);
                }
            }
            else if (type == 2)
            {
                if (mode == 1)
                {
                    Program.FinanceController.CreateExpenditure(textBoxDescription.Text, numericUpDown.Value, dateTimePicker.Value, projectID);
                }
                else if (mode == 2)
                {
                    Program.FinanceController.UpdateExpenditure(expenditure.ID, textBoxDescription.Text, numericUpDown.Value, dateTimePicker.Value);
                }
            }

            this.Close();
        }
    }
}
