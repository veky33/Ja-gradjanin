﻿namespace Ja_Gradjanin
{
    partial class ParticipantEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonParticipantCancel = new System.Windows.Forms.Button();
            this.buttonParticipantSave = new System.Windows.Forms.Button();
            this.textBoxParticipantSurname = new System.Windows.Forms.TextBox();
            this.labelSurname = new System.Windows.Forms.Label();
            this.textBoxParticipantName = new System.Windows.Forms.TextBox();
            this.labelParticipantName = new System.Windows.Forms.Label();
            this.labelParticipantRole = new System.Windows.Forms.Label();
            this.comboBoxParticipantRole = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // buttonParticipantCancel
            // 
            this.buttonParticipantCancel.Location = new System.Drawing.Point(161, 125);
            this.buttonParticipantCancel.Name = "buttonParticipantCancel";
            this.buttonParticipantCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonParticipantCancel.TabIndex = 15;
            this.buttonParticipantCancel.Text = "Cancel";
            this.buttonParticipantCancel.UseVisualStyleBackColor = true;
            this.buttonParticipantCancel.Click += new System.EventHandler(this.buttonParticipantCancelClick);
            // 
            // buttonParticipantSave
            // 
            this.buttonParticipantSave.Location = new System.Drawing.Point(14, 125);
            this.buttonParticipantSave.Name = "buttonParticipantSave";
            this.buttonParticipantSave.Size = new System.Drawing.Size(75, 23);
            this.buttonParticipantSave.TabIndex = 14;
            this.buttonParticipantSave.Text = "Save";
            this.buttonParticipantSave.UseVisualStyleBackColor = true;
            this.buttonParticipantSave.Click += new System.EventHandler(this.buttonParticipantSaveClick);
            // 
            // textBoxParticipantSurname
            // 
            this.textBoxParticipantSurname.Location = new System.Drawing.Point(115, 70);
            this.textBoxParticipantSurname.Name = "textBoxParticipantSurname";
            this.textBoxParticipantSurname.Size = new System.Drawing.Size(121, 20);
            this.textBoxParticipantSurname.TabIndex = 13;
            // 
            // labelSurname
            // 
            this.labelSurname.AutoSize = true;
            this.labelSurname.Location = new System.Drawing.Point(11, 70);
            this.labelSurname.Name = "labelSurname";
            this.labelSurname.Size = new System.Drawing.Size(49, 13);
            this.labelSurname.TabIndex = 12;
            this.labelSurname.Text = "Surname";
            // 
            // textBoxParticipantName
            // 
            this.textBoxParticipantName.Location = new System.Drawing.Point(115, 39);
            this.textBoxParticipantName.Name = "textBoxParticipantName";
            this.textBoxParticipantName.Size = new System.Drawing.Size(121, 20);
            this.textBoxParticipantName.TabIndex = 11;
            // 
            // labelParticipantName
            // 
            this.labelParticipantName.AutoSize = true;
            this.labelParticipantName.Location = new System.Drawing.Point(11, 42);
            this.labelParticipantName.Name = "labelParticipantName";
            this.labelParticipantName.Size = new System.Drawing.Size(35, 13);
            this.labelParticipantName.TabIndex = 10;
            this.labelParticipantName.Text = "Name";
            // 
            // labelParticipantRole
            // 
            this.labelParticipantRole.AutoSize = true;
            this.labelParticipantRole.Location = new System.Drawing.Point(11, 9);
            this.labelParticipantRole.Name = "labelParticipantRole";
            this.labelParticipantRole.Size = new System.Drawing.Size(29, 13);
            this.labelParticipantRole.TabIndex = 9;
            this.labelParticipantRole.Text = "Role";
            // 
            // comboBoxParticipantRole
            // 
            this.comboBoxParticipantRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxParticipantRole.FormattingEnabled = true;
            this.comboBoxParticipantRole.Location = new System.Drawing.Point(115, 6);
            this.comboBoxParticipantRole.Name = "comboBoxParticipantRole";
            this.comboBoxParticipantRole.Size = new System.Drawing.Size(121, 21);
            this.comboBoxParticipantRole.TabIndex = 8;
            // 
            // ParticipantEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(255, 161);
            this.Controls.Add(this.buttonParticipantCancel);
            this.Controls.Add(this.buttonParticipantSave);
            this.Controls.Add(this.textBoxParticipantSurname);
            this.Controls.Add(this.labelSurname);
            this.Controls.Add(this.textBoxParticipantName);
            this.Controls.Add(this.labelParticipantName);
            this.Controls.Add(this.labelParticipantRole);
            this.Controls.Add(this.comboBoxParticipantRole);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ParticipantEditForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonParticipantCancel;
        private System.Windows.Forms.Button buttonParticipantSave;
        private System.Windows.Forms.TextBox textBoxParticipantSurname;
        private System.Windows.Forms.Label labelSurname;
        private System.Windows.Forms.TextBox textBoxParticipantName;
        private System.Windows.Forms.Label labelParticipantName;
        private System.Windows.Forms.Label labelParticipantRole;
        private System.Windows.Forms.ComboBox comboBoxParticipantRole;
    }
}