﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ja_Gradjanin.Model;

namespace Ja_Gradjanin
{
    public partial class ParticipantEditForm : Form
    {
        private int mode;
        projekat_ucesnik participant;

        public ParticipantEditForm()
        {
            InitializeComponent();

            LoadLanguageString();

            comboBoxParticipantRole.DataSource = Program.ParticipantController.ListAllTypes();
            comboBoxParticipantRole.DisplayMember = "Naziv";
            mode = 1;
        }

        public ParticipantEditForm(int ID) : this()
        {
            comboBoxParticipantRole.Enabled = false;
            participant = Program.ParticipantController.GetParticipant(ID);
            foreach (projekat_ucesnik_uloga_prevod puup in comboBoxParticipantRole.Items)
            {
                if (participant.FK_UcesnikProjektaUlogaID == puup.PROJEKAT_UCESNIK_ULOGA_ID)
                {
                    comboBoxParticipantRole.SelectedItem = puup;
                    break;
                }
            }
            mode = 2;
            
            textBoxParticipantName.Text = participant.Ime;
            textBoxParticipantSurname.Text = participant.Prezime;
        }

        public void LoadLanguageString()
        {
            labelParticipantRole.Text = Program.LanguageResxSet.GetString("role");
            labelParticipantName.Text = Program.LanguageResxSet.GetString("name");
            labelSurname.Text = Program.LanguageResxSet.GetString("surname");
            buttonParticipantSave.Text = Program.LanguageResxSet.GetString("save");
            buttonParticipantCancel.Text = Program.LanguageResxSet.GetString("cancel");
        }

        private void buttonParticipantCancelClick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonParticipantSaveClick(object sender, EventArgs e)
        {
            if (comboBoxParticipantRole.SelectedItem == null || textBoxParticipantName.Text == "" || textBoxParticipantSurname.Text == "")
            {
                MessageBox.Show(Program.LanguageResxSet.GetString("typeddatanotvalid"));
            }
            else
            {
                if (mode == 1)
                {
                    if (!Program.ParticipantController.CreateParticipant(textBoxParticipantName.Text, textBoxParticipantSurname.Text, ((projekat_ucesnik_uloga_prevod)(comboBoxParticipantRole.SelectedItem)).PROJEKAT_UCESNIK_ULOGA_ID))
                    {
                        MessageBox.Show(Program.LanguageResxSet.GetString("erroroccured"));
                    } 
                    else
                    {
                        this.Close();
                    }
                }
                else if (mode == 2)
                {
                    if (!Program.ParticipantController.EditParticipant(participant.ID, textBoxParticipantName.Text, textBoxParticipantSurname.Text, ((projekat_ucesnik_uloga_prevod)(comboBoxParticipantRole.SelectedItem)).PROJEKAT_UCESNIK_ULOGA_ID))
                    {
                        MessageBox.Show(Program.LanguageResxSet.GetString("erroroccured"));
                    }
                    else
                    {
                        this.Close();
                    }
                }

            }
        }
    }
}
