﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Ja_Gradjanin.DAO;
using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.Controllers
{
    class DocumentController
    {
        IzvjestajDAO izvjestajDAO = new IzvjestajDAO();

        public List<izvjestaj> GetDocumentsList()
        {
            return izvjestajDAO.GetDocumentList();
        }

        public void SaveFile(byte[] file, string filename)
        {
            izvjestajDAO.SaveFile(file, filename, 1, System.DateTime.Today); // testing only
        }

        public izvjestaj LoadFile(int id)
        {
            return izvjestajDAO.GetFile(id);
        }

        public void DeleteFile(int id)
        {
            izvjestajDAO.DeleteFile(id);
        }
    }
}
