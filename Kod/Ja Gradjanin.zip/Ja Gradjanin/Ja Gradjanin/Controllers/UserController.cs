﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Windows.Forms;

using Ja_Gradjanin.Model;
using Ja_Gradjanin.DAO;

namespace Ja_Gradjanin.Controllers
{
    class UserController
    {
        private korisnik currentUser;
        private bool userLoggedIn = false;
        private KorisnikDAO korisnikDAO = new KorisnikDAO();

        public korisnik CurrentUser { get => currentUser; set => currentUser = value; }
        public bool UserLoggedIn { get => userLoggedIn; set => userLoggedIn = value; }

        /// <summary>
        /// Encrypting password
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        private string passwordDigest(string password)
        {
            byte[] result = new byte[128];
            byte[] result1;

            char[] salt = { 'J', 'o', 'v', '@', 'n', 'k', 'a' };
            byte[] resultSalt;
            byte[] hash;
            SHA512Managed sHA512M;
            UTF8Encoding uTF = new UTF8Encoding();
            using (sHA512M = new SHA512Managed())
            {
                result1 = sHA512M.ComputeHash(uTF.GetBytes(password));
                resultSalt = sHA512M.ComputeHash(uTF.GetBytes(salt));

                System.Buffer.BlockCopy(resultSalt, 0, result, 0, 64);
                System.Buffer.BlockCopy(result1, 0, result, 64, 64);
                hash = sHA512M.ComputeHash(result);
            }

            //MessageBox.Show(BitConverter.ToString(hash).Replace("-", ""));
            StringBuilder hex = new StringBuilder(128);
            return BitConverter.ToString(hash).Replace("-", "");

        }


        /// <summary>
        /// Verifies username and password. If any of supplied values are incorrect, method will return false. If credentials are valied, method will return true and assign field currentUser
        /// </summary>
        /// <returns></returns>
        public bool VerifyLogin(string username, string password)
        {
            //MessageBox.Show(passwordDigest(username, password));

            korisnik tmpUser = korisnikDAO.GetSpecificUserByUsername(username);

            if (tmpUser == null )
            {
                return false;
            }
            else
            {
                //MessageBox.Show(tmpUser.Status.ToString());
                if (tmpUser.Status && korisnikDAO.GetPasswordHash(username) == passwordDigest(password))
                {
                    CurrentUser = tmpUser;
                    UserLoggedIn = true;
                    return true;
                }
                else
                {
                    return false;
                }
            }

            
        }

        public List<korisnik> ListAllUsers()
        {
            return korisnikDAO.ListAllUsers(true);
        }

        public bool CreateNewUser(string name, string surname, string userName, string password, int language, int usertype, int teritoryUnit)
        {
            if (currentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 1 && password != "")
            {
                return korisnikDAO.CreateUser(name, surname, userName, passwordDigest(password), language, usertype, teritoryUnit);
            }
            else
            {
                return false;
            }
            
        }

        public bool UpdateUser(int id, string name, string surname, string userName, int language, int usertype, int teritoryUnit)
        {
            if (currentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 1)
            {
                return korisnikDAO.UpdateUser(id, name, surname, userName, language, usertype, teritoryUnit);
            }
            else
            {
                return false;
            }

        }

        public bool DeleteUser(int id)
        {
            if (currentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 1)
            {
                return korisnikDAO.SetUserStatus(false, id);
            }
            else
            {
                return false;
            }
        }

        public bool ChangePassword(int id, string password)
        {
            if (currentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 1)
            {
                return korisnikDAO.SetPasswordHash(passwordDigest(password), id);
            }
            else
            {
                return false;
            }
        }

        public List<korisnik_vrsta> GetAllUserTypes()
        {
            return korisnikDAO.GetUserTypes();
        }

        public korisnik GetUserByID(int id)
        {
            return korisnikDAO.GetSpecificUserByID(id);
        }
    }
}
