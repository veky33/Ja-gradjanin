﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Ja_Gradjanin.Model;
using Ja_Gradjanin.DAO;

namespace Ja_Gradjanin.Controllers
{
    class ParticipantController
    {

        Projekat_UcesnikDAO ucesnikDAO = new Projekat_UcesnikDAO();

        public List<projekat_ucesnik> ListParticipants()
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return ucesnikDAO.GetAllParticipants();
            }
            else
            {
                return null;
            }
        }

        public bool CreateParticipant(string name, string surname, int typeID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return ucesnikDAO.CreateParticipant(name, surname, typeID);
            }
            else
            {
                return false;
            }
        }

        public bool EditParticipant(int ID, string name, string surname, int typeID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return ucesnikDAO.UpdateParticipant(ID, name, surname, typeID);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteParticipant(int ID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return ucesnikDAO.DeleteParticipant(ID);
            }
            else
            {
                return false;
            }
        }

        public List<projekat_ucesnik_uloga_prevod> ListAllTypes()
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return ucesnikDAO.GetParticipantTypes(3); //serbian hardcoded
            }
            else
            {
                return null;
            }
        }

        public projekat_ucesnik_uloga_prevod GetSpecificRoleName(int typeID, int langID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return ucesnikDAO.GetSpecificRoleName(typeID, langID);
            }
            else
            {
                return null;
            }
        }

        public projekat_ucesnik GetParticipant(int ID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return ucesnikDAO.GetParticipant(ID);
            }
            else
            {
                return null;
            }
        }

        public List<projekat_ucesnik> ListParticipantsByRole(int roleID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return ucesnikDAO.GetParticipantsByRole(roleID);
            }
            else
            {
                return null;
            }
        }


    }
}
