﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Ja_Gradjanin.DAO;
using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.Controllers
{
    class TeritoryController
    {
        TeritorijalnaJedinicaDAO teritorijalnaJedinicaDAO = new TeritorijalnaJedinicaDAO();


        public List<teritorijalna_jedinica> GetTeritoryAndSubteritories(int ID)
        {
            List<teritorijalna_jedinica> result = new List<teritorijalna_jedinica>();
            result.Add(teritorijalnaJedinicaDAO.GetTeritoryByID(ID));

            List<teritorijalna_jedinica> tmp = GetSubTeritories(ID,true);
            result.AddRange(tmp);
            return result;
        }

        public List<teritorijalna_jedinica> GetSubTeritories(int ID, bool recursion)
        {
            List<teritorijalna_jedinica> result = new List<teritorijalna_jedinica>();
            List<teritorijalna_jedinica> tmp = teritorijalnaJedinicaDAO.GetTeritoriesBySuperTeritory(ID);
            if (tmp.Count > 0)
            {
                result.AddRange(tmp);

                if (recursion)
                {
                    foreach (teritorijalna_jedinica t in tmp)
                    {
                        result.AddRange(GetSubTeritories(t.ID, recursion));
                    }
                }
            }
            return result;
        }

        public teritorijalna_jedinica GetTeritory(int ID)
        {
            return teritorijalnaJedinicaDAO.GetTeritoryByID(ID);
        }

        public List<teritorijalna_jedinica> GetStates()
        {
            return teritorijalnaJedinicaDAO.GetTeritoriesByDepth(1);
        }
    }
}
