﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Ja_Gradjanin.Model;
using Ja_Gradjanin.DAO;
using System.Windows.Forms;

namespace Ja_Gradjanin.Controllers
{
    class ProjectController
    {
        private ProjekatDAO projekatDAO = new ProjekatDAO();
        private Projekat_KoordinatorDAO projekat_KoordinatorDAO = new Projekat_KoordinatorDAO();
        private Projekat_MentorDAO projekat_MentorDAO = new Projekat_MentorDAO();
        private Projekat_NastavnikDAO projekat_NastavnikDAO = new Projekat_NastavnikDAO();
        private Projekat_VodjaDAO projekat_VodjaDAO = new Projekat_VodjaDAO();
        private Projekat_UcenikDAO projekat_UcenikDAO = new Projekat_UcenikDAO();


        private List<projekat> projects = new List<projekat>();



        public List<projekat> ListProjects(bool search, string searchtext)
        {
            projects.Clear();
            

            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                
                // glavni koordinator
                if (Program.UserController.CurrentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 1) //admin
                {
                    if (!search)
                    {
                        projects = projekatDAO.ListAllProjects();
                    }
                    else
                    {
                        projects = projekatDAO.SearchProjects(searchtext);
                    }
                    
                }
                // regionalni  koordinatori
                else if (Program.UserController.CurrentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 2) //region
                {
                    List<teritorijalna_jedinica> ter = Program.TeritoryController.GetTeritoryAndSubteritories(Program.UserController.CurrentUser.FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID);


                    foreach (teritorijalna_jedinica t in ter)
                    {
                        if (!search)
                        {
                            projects.AddRange(projekatDAO.ListProjectsByTeritory(t.ID));
                        }
                        else
                        {
                            projects.AddRange(projekatDAO.ListProjectByTerritorySearch(t.ID, searchtext));
                        }
                    }
                    
                }

                else if (Program.UserController.CurrentUser.FK_VrstaKorisnika_VrstaKorisnikaID == 3) //teacher
                {

                }


            }
            

            return projects;
        }
        

        // now hardoced, have to read from database in future (sometime)
        public string GetProjekatStatus(int statusID)
        {
            int languageID = 0;
            
            if (Program.Language == Program.Languages.Serbian)
            {
                languageID = 3;
            }
            else if (Program.Language == Program.Languages.Croatian)
            {
                languageID = 2;
            }
            else if (Program.Language == Program.Languages.Bosnian)
            {
                languageID = 1;
            }

            //projekat_status_prevod status = projekatDAO.GetProjectStatusName(languageID, statusID);
            projekat_status_prevod status = projekatDAO.GetProjectStatusName(3, statusID);

            if (status == null)
            {
                return "";
            }
            else
            {
                return status.Naziv;
            }
        }
    

        public bool DeleteProject(int ID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                projekat_KoordinatorDAO.DeleteProjectCoordinatorConnections(ID);
                projekat_MentorDAO.DeleteProjectMentor(ID);
                projekat_NastavnikDAO.DeleteProjectNastavnik(ID);
                projekat_VodjaDAO.DeleteProjectVodja(ID);
                projekat_UcenikDAO.DeleteProjectStudents(ID);
                Program.FinanceController.DeleteAllProjectFinances(ID);
                return projekatDAO.DeleteProject(ID);
            } 
            else
            {
                return false;
            }
        }

        public projekat GetProject(int ID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekatDAO.GetProjectByID(ID);
            }
            else
            {
                return null;
            }
        }

        public List<projekat_status_prevod> GetProjectStatusList()
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekatDAO.GetAllProjectStatuses(3); //hardkodovan srpski
            }
            else
            {
                return null;
            }
        }

        public bool CreateProject(string name, string description, DateTime dateStart, DateTime dateEnd, decimal budget, decimal percentage, int projectstatusID, int territoryunitID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                if  (projekatDAO.CreateProject(name, description, dateStart, dateEnd, budget, percentage, projectstatusID, territoryunitID))
                {
                    projekat_KoordinatorDAO.CreateProjectCoordinatorConnection(projekatDAO.GetLastCreatedProject().ID, Program.UserController.CurrentUser.ID);
                    return true;
                } 
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public projekat GetLastCreatedProject()
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekatDAO.GetLastCreatedProject();
            }
            else
            {
                return null;
            }
        }

        public bool UpdateProject(int ID, string name, string description, DateTime dateStart, DateTime dateEnd, decimal budget, decimal percentage, int projectstatusID, int teritoryunitID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekatDAO.UpdateProject(ID, name, description, dateStart, dateEnd, budget, percentage, projectstatusID, teritoryunitID);
            }
            else
            {
                return false;
            }
        }

        public bool CreateProjectMentor(int projectID, int mentorID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                projekat_MentorDAO.DeleteProjectMentor(projectID);
                return projekat_MentorDAO.CreateProjectMentor(projectID, mentorID);
            }
            else
            {
                return false;
            }
        }

        public projekat_mentor GetProjectMentor(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekat_MentorDAO.GetProjectMentor(projectID);
            }
            else
            {
                return null;
            }
        }

        public bool DeleteProjectMentor(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekat_MentorDAO.DeleteProjectMentor(projectID);
            }
            else
            {
                return false;
            }
        }

        public bool CreateProjectNastavnik(int projectID, int nastavnikID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                projekat_NastavnikDAO.DeleteProjectNastavnik(projectID);
                return projekat_NastavnikDAO.CreateProjectNastavnik(projectID, nastavnikID);
            }
            else
            {
                return false;
            }
        }

        public projekat_nastavnik GetProjectNastavnik(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekat_NastavnikDAO.GetProjectNastavnik(projectID);
            }
            else
            {
                return null;
            }
        }

        public bool DeleteProjectNastavnik(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekat_NastavnikDAO.DeleteProjectNastavnik(projectID);
            }
            else
            {
                return false;
            }
        }

        public bool CreateProjectVodja(int projectID, int vodjaID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                projekat_VodjaDAO.DeleteProjectVodja(projectID);
                return projekat_VodjaDAO.CreateProjectVodja(projectID, vodjaID);
            }
            else
            {
                return false;
            }
        }

        public projekat_vodja GetProjectVodja(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekat_VodjaDAO.GetProjectVodja(projectID);
            }
            else
            {
                return null;
            }
        }

        public bool DeleteProjectVodja(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekat_VodjaDAO.DeleteProjectVodja(projectID);
            }
            else
            {
                return false;
            }
        }

        public List<projekat_ucenik> GetProjectStudents(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekat_UcenikDAO.GetAllProjectStudents(projectID);
            }
            else
            {
                return null;
            }
        }

        public bool CreateProjectStudent(int projectID, int studentID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekat_UcenikDAO.CreateProjectStudent(projectID, studentID);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteProjectStudent(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return projekat_UcenikDAO.DeleteProjectStudents(projectID);
            }
            else
            {
                return false;
            }
        }
    }
}
