﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Ja_Gradjanin.DAO;
using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.Controllers
{
    class FinanceController
    {
        private PrihodDAO prihodDAO = new PrihodDAO();
        private RashodDAO rashodDAO = new RashodDAO();


        public List<prihod> GetProjectIncomes(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return prihodDAO.GetProjectIncomes(projectID);
            }
            else
            {
                return null;
            }
        }

        public List<rashod> GetProjectExpenditures(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return rashodDAO.GetProjectExpenditures(projectID);
            }
            else
            {
                return null;
            }
        }

        public prihod GetSpecificIncome(int id)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return prihodDAO.GetSpecificIncome(id);
            }
            else
            {
                return null;
            }
        }


        public rashod GetSpecificExpenditure(int id)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return rashodDAO.GetSpecificExpenditure(id);
            }
            else
            {
                return null;
            }
        }

        public bool CreateIncome(string description, decimal ammount, string financier, DateTime date, int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return prihodDAO.CreateIncome(description, ammount, financier, date, projectID);
            }
            else
            {
                return false;
            }
        }

        public bool CreateExpenditure(string description, decimal ammount, DateTime date, int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return rashodDAO.CreateExpenditure(description, ammount, date, projectID);
            }
            else
            {
                return false;
            }
        }

        public bool UpdateIncome(int id, string description, decimal amount, string financier, DateTime date)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return prihodDAO.UpdateIncome(id, description, amount, financier, date);
            }
            else
            {
                return false;
            }
        }

        public bool UpdateExpenditure(int id, string description, decimal amount, DateTime date)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return rashodDAO.UpdateExpenditure(id, description, amount, date);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteIncome(int id)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return prihodDAO.DeleteIncome(id);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteExpenditure(int id)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                return rashodDAO.DeleteExpenditure(id);
            }
            else
            {
                return false;
            }
        }

        public void DeleteAllProjectFinances(int projectID)
        {
            if (Program.UserController.UserLoggedIn && Program.UserController.CurrentUser != null)
            {
                prihodDAO.DeleteProjectIncomes(projectID);
                rashodDAO.DeleteProjectExpenditures(projectID);
            }
            else
            {
                return ;
            }
        }
    }
}
