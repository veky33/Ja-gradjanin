﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO
{
    class Projekat_NastavnikDAO
    {
        private string DELETE_PROJECT_NASTAVNIK_CONNECTIONS = @"DELETE FROM PROJEKAT_NASTAVNIK WHERE FK_ProjekatID=?FK_ProjekatID;";
        private string CREATE_PROJECT_NASTAVNIK_CONNECTION = @"INSERT INTO PROJEKAT_NASTAVNIK (FK_ProjekatID, FK_UcesnikProjektaID) VALUES (?FK_ProjekatID, ?FK_UcesnikProjektaID);";
        private string GET_PROJECT_NASTAVNIK_CONNECTION = @"SELECT * FROM PROJEKAT_NASTAVNIK WHERE FK_ProjekatID=?FK_ProjekatID;";


        public projekat_nastavnik GetProjectNastavnik(int projectID)
        {
            projekat_nastavnik result = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_PROJECT_NASTAVNIK_CONNECTION, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    result = new projekat_nastavnik();
                    result.ID = reader.GetInt32("ID");
                    result.FK_ProjekatID = reader.GetInt32("FK_ProjekatID");
                    result.FK_UcesnikProjektaID = reader.GetInt32("FK_UcesnikProjektaID");
                }
            }

            return result;
        }

        public bool CreateProjectNastavnik(int projectID, int nastavnikID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(CREATE_PROJECT_NASTAVNIK_CONNECTION, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Parameters.AddWithValue("FK_UcesnikProjektaID", nastavnikID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    return true;
                }
            }

            return result;
        }

        public bool DeleteProjectNastavnik(int projectID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(DELETE_PROJECT_NASTAVNIK_CONNECTIONS, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    return true;
                }

            }

            return result;
        }
    }
}
