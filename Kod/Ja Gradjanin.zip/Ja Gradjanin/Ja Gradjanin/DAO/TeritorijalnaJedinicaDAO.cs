﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Configuration;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO

{
    class TeritorijalnaJedinicaDAO
    {
        private string GET_TERITORY_BY_ID = @"SELECT * FROM TERITORIJALNA_JEDINICA WHERE ID=?ID;";
        private string GET_TERITORIES_BY_SUPERTERITORY = @"SELECT * FROM TERITORIJALNA_JEDINICA WHERE FK_NadTeritorijalnaJedinica=?FK_NadTeritorijalnaJedinica;";
        private string GET_TERITORIES_BY_DEPTH = @"SELECT * FROM TERITORIJALNA_JEDINICA INNER JOIN TERITORIJALNA_JEDINICA_VRSTA ON TERITORIJALNA_JEDINICA.FK_VrstaTeritorijalneJedinice_VrstaTeritorijalneJediniceID = TERITORIJALNA_JEDINICA_VRSTA.ID AND TERITORIJALNA_JEDINICA_VRSTA.Dubina = ?Dubina;";


        public teritorijalna_jedinica GetTeritoryByID(int ID)
        {
            teritorijalna_jedinica teritory = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_TERITORY_BY_ID, conn);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    teritory = new teritorijalna_jedinica();
                    teritory.ID = reader.GetInt32("ID");
                    teritory.Naziv = reader.GetString("Naziv");
                    teritory.FK_VrstaTeritorijalneJedinice_VrstaTeritorijalneJediniceID = reader.GetInt32("FK_VrstaTeritorijalneJedinice_VrstaTeritorijalneJediniceID");
                    teritory.FK_NadTeritorijalnaJedinica = reader.GetInt32("FK_NadTeritorijalnaJedinica");
                }
            }

            return teritory;
        }

        public List<teritorijalna_jedinica> GetTeritoriesBySuperTeritory(int ID)
        {
            List<teritorijalna_jedinica> teritories = new List<teritorijalna_jedinica>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_TERITORIES_BY_SUPERTERITORY, conn);
                comm.Parameters.AddWithValue("FK_NadTeritorijalnaJedinica", ID);
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    teritorijalna_jedinica teritory = new teritorijalna_jedinica();
                    teritory.ID = reader.GetInt32("ID");
                    teritory.Naziv = reader.GetString("Naziv");
                    teritory.FK_VrstaTeritorijalneJedinice_VrstaTeritorijalneJediniceID = reader.GetInt32("FK_VrstaTeritorijalneJedinice_VrstaTeritorijalneJediniceID");
                    teritory.FK_NadTeritorijalnaJedinica = reader.GetInt32("FK_NadTeritorijalnaJedinica");
                    teritories.Add(teritory);
                }
            }

            return teritories;

        }

        public List<teritorijalna_jedinica> GetTeritoriesByDepth(int depth)
        {
            List<teritorijalna_jedinica> result = new List<teritorijalna_jedinica>();
            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_TERITORIES_BY_DEPTH, conn);
                comm.Parameters.AddWithValue("Dubina", depth);
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    teritorijalna_jedinica teritory = new teritorijalna_jedinica();
                    teritory.ID = reader.GetInt32("ID");
                    teritory.Naziv = reader.GetString("Naziv");
                    teritory.FK_VrstaTeritorijalneJedinice_VrstaTeritorijalneJediniceID = reader.GetInt32("FK_VrstaTeritorijalneJedinice_VrstaTeritorijalneJediniceID");
                    teritory.FK_NadTeritorijalnaJedinica = reader.GetInt32("FK_NadTeritorijalnaJedinica");
                    result.Add(teritory);
                }
            }
            return result;
        }



    }
}
