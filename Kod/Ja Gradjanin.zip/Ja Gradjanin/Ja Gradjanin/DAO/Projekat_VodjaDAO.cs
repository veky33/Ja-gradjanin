﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO
{
    class Projekat_VodjaDAO
    {
        private string DELETE_PROJECT_VODJA_CONNECTIONS = @"DELETE FROM PROJEKAT_VODJA WHERE FK_ProjekatID=?FK_ProjekatID;";
        private string CREATE_PROJECT_VODJA_CONNECTION = @"INSERT INTO PROJEKAT_VODJA (FK_ProjekatID, FK_UcesnikProjektaID) VALUES (?FK_ProjekatID, ?FK_UcesnikProjektaID);";
        private string GET_PROJECT_VODJA_CONNECTION = @"SELECT * FROM PROJEKAT_VODJA WHERE FK_ProjekatID=?FK_ProjekatID;";


        public projekat_vodja GetProjectVodja(int projectID)
        {
            projekat_vodja result = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_PROJECT_VODJA_CONNECTION, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    result = new projekat_vodja();
                    result.ID = reader.GetInt32("ID");
                    result.FK_ProjekatID = reader.GetInt32("FK_ProjekatID");
                    result.FK_UcesnikProjektaID = reader.GetInt32("FK_UcesnikProjektaID");
                }
            }

            return result;
        }

        public bool CreateProjectVodja(int projectID, int vodjaID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(CREATE_PROJECT_VODJA_CONNECTION, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Parameters.AddWithValue("FK_UcesnikProjektaID", vodjaID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    return true;
                }
            }

            return result;
        }

        public bool DeleteProjectVodja(int projectID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(DELETE_PROJECT_VODJA_CONNECTIONS, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    return true;
                }

            }

            return result;
        }
    }
}
