﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Configuration;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO
{
    class Projekat_UcesnikDAO
    {
        private string GET_ALL_PARTICIPANTS = @"SELECT * FROM PROJEKAT_UCESNIK;";
        private string CREATE_PARTICIPANT = @"INSERT INTO PROJEKAT_UCESNIK (Ime, Prezime, FK_UcesnikProjektaUlogaID) VALUES(?Ime, ?Prezime, ?FK_UcesnikProjektaUlogaID);";
        private string UPDATE_PARTICIPANT = @"UPDATE PROJEKAT_UCESNIK SET Ime=?Ime, Prezime=?Prezime, FK_UcesnikProjektaUlogaID=?FK_UcesnikProjektaUlogaID WHERE ID=?ID;";
        private string DELETE_PARTICPANT = @"DELETE FROM PROJEKAT_UCESNIK WHERE ID=?ID;";
        private string GET_SPECIFIC_TYPE_NAME = @"SELECT * FROM projekat_ucesnik_uloga_prevod WHERE JEZIK_ID=?JEZIK_ID AND PROJEKAT_UCESNIK_ULOGA_ID=?PROJEKAT_UCESNIK_ULOGA_ID;";
        private string GET_SPECIFIC_PARTICIPANT = @"SELECT * FROM PROJEKAT_UCESNIK WHERE ID=?ID;";
        private string GET_TYPE_NAMES = @"SELECT * FROM projekat_ucesnik_uloga_prevod WHERE JEZIK_ID=?JEZIK_ID;";
        private string GET_PARTICIPANTS_BY_ROLE = @"SELECT * FROM PROJEKAT_UCESNIK WHERE FK_UcesnikProjektaUlogaID=?FK_UcesnikProjektaUlogaID ORDER BY ID DESC;";

        public List<projekat_ucesnik> GetAllParticipants ()
        {
            List<projekat_ucesnik> result = new List<projekat_ucesnik>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_ALL_PARTICIPANTS, conn);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    projekat_ucesnik p = new projekat_ucesnik();
                    p.ID = reader.GetInt32("ID");
                    p.Ime = reader.GetString("Ime");
                    p.Prezime = reader.GetString("Prezime");
                    p.FK_UcesnikProjektaUlogaID = reader.GetInt32("FK_UcesnikProjektaUlogaID");
                    result.Add(p);
                }
            }

            return result;
        }

        public bool CreateParticipant(string name, string surname, int type)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(CREATE_PARTICIPANT, conn);
                comm.Parameters.AddWithValue("Ime", name);
                comm.Parameters.AddWithValue("Prezime", surname);
                comm.Parameters.AddWithValue("FK_UcesnikProjektaUlogaID", type);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

                return result;
        }

        public bool UpdateParticipant(int ID, string name, string surname, int type)
        {
            bool result = false;
            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(UPDATE_PARTICIPANT, conn);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Parameters.AddWithValue("Ime", name);
                comm.Parameters.AddWithValue("Prezime", surname);
                comm.Parameters.AddWithValue("FK_UcesnikProjektaUlogaID", type);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }
            return result;
        }

        public bool DeleteParticipant(int ID)
        {
            bool result = false;
            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(DELETE_PARTICPANT, conn);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }
            return result;
        }

        public List<projekat_ucesnik_uloga_prevod> GetParticipantTypes(int langID)
        {
            List<projekat_ucesnik_uloga_prevod> result = new List<projekat_ucesnik_uloga_prevod>();
            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_TYPE_NAMES, conn);
                comm.Parameters.AddWithValue("JEZIK_ID", langID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    projekat_ucesnik_uloga_prevod puup = new projekat_ucesnik_uloga_prevod();
                    puup.Naziv = reader.GetString("Naziv");
                    puup.Opis = reader.GetString("Opis");
                    puup.JEZIK_ID = reader.GetInt32("JEZIK_ID");
                    puup.PROJEKAT_UCESNIK_ULOGA_ID = reader.GetInt32("PROJEKAT_UCESNIK_ULOGA_ID");
                    result.Add(puup);
                }
            }
            return result;
        }

        public projekat_ucesnik_uloga_prevod GetSpecificRoleName(int typeID, int langID)
        {
            projekat_ucesnik_uloga_prevod result = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_SPECIFIC_TYPE_NAME, conn);
                comm.Parameters.AddWithValue("JEZIK_ID", langID);
                comm.Parameters.AddWithValue("PROJEKAT_UCESNIK_ULOGA_ID", typeID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    result = new projekat_ucesnik_uloga_prevod();
                    result.Naziv = reader.GetString("Naziv");
                    result.Opis = reader.GetString("Opis");
                    result.JEZIK_ID = reader.GetInt32("JEZIK_ID");
                    result.PROJEKAT_UCESNIK_ULOGA_ID = reader.GetInt32("PROJEKAT_UCESNIK_ULOGA_ID");
                }
            }

            return result;
        }

        public projekat_ucesnik GetParticipant(int ID)
        {
            projekat_ucesnik result = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_SPECIFIC_PARTICIPANT, conn);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    result = new projekat_ucesnik();
                    result.ID = reader.GetInt32("ID");
                    result.Ime = reader.GetString("Ime");
                    result.Prezime = reader.GetString("Prezime");
                    result.FK_UcesnikProjektaUlogaID = reader.GetInt32("FK_UcesnikProjektaUlogaID");
                }
            }

            return result;
        }

        public List<projekat_ucesnik> GetParticipantsByRole(int roleID)
        {
            List<projekat_ucesnik> result = new List<projekat_ucesnik>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_PARTICIPANTS_BY_ROLE, conn);
                comm.Parameters.AddWithValue("FK_UcesnikProjektaUlogaID", roleID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    projekat_ucesnik p = new projekat_ucesnik();
                    p.ID = reader.GetInt32("ID");
                    p.Ime = reader.GetString("Ime");
                    p.Prezime = reader.GetString("Prezime");
                    p.FK_UcesnikProjektaUlogaID = reader.GetInt32("FK_UcesnikProjektaUlogaID");
                    result.Add(p);
                }
            }

            return result;
        }
    }
}
