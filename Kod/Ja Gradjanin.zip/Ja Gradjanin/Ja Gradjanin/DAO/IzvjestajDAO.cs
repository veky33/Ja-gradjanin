﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO
{
    class IzvjestajDAO
    {
        private string GET_ALL_REPORTS = @"SELECT ID, FK_Projekat_ProjekatID, DatumKreiranja, IZVJESTAJ_TIP_ID, FK_Korisnik_ID, FileName FROM IZVJESTAJ;";
        private string GET_ALL_REPORTS_BY_PROJECT = @"SELECT ID, FK_Projekat_ProjekatID, DatumKreiranja, IZVJESTAJ_TIP_ID, FK_Korisnik_ID FROM IZVJESTAJ WHERE FK_Projekat_ProjekatID=?ProjekatID ;";
        private string GET_REPORT_FILE = @"SELECT File,FileName,FileSize FROM IZVJESTAJ WHERE ID=?ID;";
        private string SAVE_FILE = @"INSERT INTO Izvjestaj (File, FileName, FileSize, FK_Projekat_ProjekatID, DatumKreiranja, FK_Korisnik_ID) VALUES (?File, ?FileName, ?FileSize, ?FK_Projekat_ProjekatID, ?DatumKreiranja, ?FK_Korisnik_ID);";
        private string DELETE_FILE = @"DELETE FROM Izvjestaj WHERE ID=?ID";


        public List<izvjestaj> GetDocumentList()
        {
            List<izvjestaj> result = new List<izvjestaj>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_ALL_REPORTS, conn);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    izvjestaj i = new izvjestaj();
                    i.ID = reader.GetInt32("ID");
                    i.FK_Projekat_ProjekatID = reader.GetInt32("FK_Projekat_ProjekatID");
                    i.DatumKreiranja = reader.GetDateTime("DatumKreiranja");
                    //i.IZVJESTAJ_TIP_ID = reader.GetInt32("IZVJESTAJ_TIP_ID");
                    i.FK_Korisnik_ID = reader.GetInt32("FK_Korisnik_ID");
                    i.FileName = reader.GetString("FileName");
                    result.Add(i);
                }
            }
            
            return result;
        }

        public izvjestaj GetFile(int fileid)
        {
            izvjestaj izv = null;

            MySqlParameter[] parameters = new MySqlParameter[1];
            parameters[0] = new MySqlParameter("ID", fileid);

            MySqlDataReader reader = MySqlHelper.ExecuteReader(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString, GET_REPORT_FILE, parameters);
            while (reader.Read())
            {
                izv = new izvjestaj();
                izv.FileSize = reader.GetUInt64("FileSize");
                izv.FileName = reader.GetString("FileName");
                izv.File = new byte[izv.FileSize];
                reader.GetBytes(reader.GetOrdinal("File"), 0, izv.File, 0, (Int32)izv.FileSize);
            }

            return izv;
        }

        public bool SaveFile(byte[] file, string filename, int projectID, DateTime date)
        {

            MySqlParameter[] parameters = new MySqlParameter[6];
            parameters[0] = new MySqlParameter("File", file);
            parameters[1] = new MySqlParameter("FileName", filename);
            parameters[2] = new MySqlParameter("FileSize", file.LongLength);
            parameters[3] = new MySqlParameter("FK_Projekat_ProjekatID", projectID); 
            parameters[4] = new MySqlParameter("DatumKreiranja", date);
            parameters[5] = new MySqlParameter("FK_Korisnik_ID", Program.UserController.CurrentUser.ID);
            int querry = MySqlHelper.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString, SAVE_FILE, parameters);

            return querry != -1;
        }

        public bool DeleteFile(int ID)
        {
            MySqlParameter[] parameters = new MySqlParameter[1];
            parameters[0] = new MySqlParameter("ID", ID);
            int querry = MySqlHelper.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString, DELETE_FILE, parameters);

            return querry != -1;
        }
    }
}
