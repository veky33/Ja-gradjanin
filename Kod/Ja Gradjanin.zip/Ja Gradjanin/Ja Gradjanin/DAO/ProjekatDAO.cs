﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO
{
    class ProjekatDAO
    {
        private string LIST_ALL_PROJECTS = @"SELECT * FROM Projekat;";
        private string CREATE_PROJECT = @"INSERT INTO PROJEKAT (Naziv, Opis, DatumPocetka, DatumZavrsetka, Budzet, ProcenatZavrsenosti, FK_ProjekatStatusID, FK_TeritorijalnaJedinica_ID) VALUES (?Naziv, ?Opis, ?DatumPocetka, ?DatumZavrsetka, ?Budzet, ?ProcenatZavrsenosti, ?FK_ProjekatStatusID, ?FK_TeritorijalnaJedinica_ID);";
        private string DELETE_PROJECT = @"DELETE FROM PROJEKAT WHERE ID=?ID;";
        private string LIST_PROJECTS_BY_TERITORY = @"SELECT * FROM PROJEKAT WHERE FK_TeritorijalnaJedinica_ID=?FK_TeritorijalnaJedinica_ID;";
        private string GET_PROJECT_STATUS_NAME = @"SELECT * FROM PROJEKAT_STATUS_PREVOD WHERE JEZIK_ID=?JEZIK_ID AND PROJEKAT_STATUS_ID=?PROJEKAT_STATUS_ID";
        private string GET_PROJECT_BY_ID = @"SELECT * FROM PROJEKAT WHERE ID=?ID;";
        private string LIST_PROJECT_STATUSES = @"SELECT * FROM PROJEKAT_STATUS_PREVOD WHERE JEZIK_ID=?JEZIK_ID";
        private string UPDATE_PROJECT = @"UPDATE PROJEKAT SET Naziv=?Naziv, Opis=?Opis, DatumPocetka=?DatumPocetka, DatumZavrsetka=?DatumZavrsetka, ProcenatZavrsenosti=?ProcenatZavrsenosti, Budzet=?Budzet, FK_ProjekatStatusID=?FK_ProjekatStatusID, FK_TeritorijalnaJedinica_ID=?FK_TeritorijalnaJedinica_ID WHERE ID=?ID;";
        private string LINK_COORDINATOR = @"INSERT INTO PROJEKAT_KOORDINATOR (FK_Korisnik_KorisnikID, FK_Projekat_ProjekatID) VALUES (?FK_Korisnik_KorisnikID, ?FK_Projekat_ProjekatID);";
        private string SEARCH_PROJECTS = @"SELECT * FROM Projekat WHERE Naziv OR Opis LIKE ?upit;";
        private string LIST_PROJECTS_BY_TERITORY_SEARCH = @"SELECT * FROM PROJEKAT WHERE FK_TeritorijalnaJedinica_ID=?FK_TeritorijalnaJedinica_ID AND Naziv OR Opis LIKE ?upit;";



        private long LAST_INSERTED_ID;


        public List<projekat> ListAllProjects()
        {
            List<projekat> projects = new List<projekat>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(LIST_ALL_PROJECTS, conn);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    projekat project = new projekat();
                    project.ID = reader.GetInt32("ID");
                    project.Naziv = reader.GetString("Naziv");
                    project.Opis = reader.GetString("Opis");
                    project.DatumPocetka = reader.GetDateTime("DatumPocetka");
                    project.DatumZavrsetka = reader.GetDateTime("DatumZavrsetka");
                    project.ProcenatZavrsenosti = reader.GetDecimal("ProcenatZavrsenosti");
                    project.Budzet = reader.GetDecimal("Budzet");
                    project.FK_ProjekatStatusID = reader.GetInt32("FK_ProjekatStatusID");
                    project.FK_TeritorijalnaJedinica_ID = reader.GetInt32("FK_TeritorijalnaJedinica_ID");
                    projects.Add(project);
                }
            }

            return projects;
        }

        public bool CreateProject(string name, string description, DateTime dateStart, DateTime dateEnd, decimal budget, decimal percentage, int projectstatusID, int teritoryunitID)
        {

            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(CREATE_PROJECT, conn);
                comm.Parameters.AddWithValue("Naziv", name);
                comm.Parameters.AddWithValue("Opis", description);
                comm.Parameters.AddWithValue("DatumPocetka", dateStart);
                comm.Parameters.AddWithValue("DatumZavrsetka", dateEnd);
                comm.Parameters.AddWithValue("Budzet", budget);
                comm.Parameters.AddWithValue("ProcenatZavrsenosti", percentage);
                comm.Parameters.AddWithValue("FK_ProjekatStatusID", projectstatusID);
                comm.Parameters.AddWithValue("FK_TeritorijalnaJedinica_ID", teritoryunitID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                    LAST_INSERTED_ID = comm.LastInsertedId;
                }
            }

            return result;
        }

        public bool DeleteProject(int projectID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(DELETE_PROJECT, conn);
                comm.Parameters.AddWithValue("ID", projectID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return result;
        }

        public List<projekat> ListProjectsByTeritory(int teritoryID)
        {
            List<projekat> projects = new List<projekat>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(LIST_PROJECTS_BY_TERITORY, conn);
                comm.Parameters.AddWithValue("FK_TeritorijalnaJedinica_ID", teritoryID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    projekat project = new projekat();
                    project.ID = reader.GetInt32("ID");
                    project.Naziv = reader.GetString("Naziv");
                    project.Opis = reader.GetString("Opis");
                    project.DatumPocetka = reader.GetDateTime("DatumPocetka");
                    project.DatumZavrsetka = reader.GetDateTime("DatumZavrsetka");
                    project.ProcenatZavrsenosti = reader.GetDecimal("ProcenatZavrsenosti");
                    project.Budzet = reader.GetDecimal("Budzet");
                    project.FK_ProjekatStatusID = reader.GetInt32("FK_ProjekatStatusID");
                    project.FK_TeritorijalnaJedinica_ID = reader.GetInt32("FK_TeritorijalnaJedinica_ID");
                    projects.Add(project);
                }
            }

            return projects;
        }

        public projekat_status_prevod GetProjectStatusName(int languageID, int statusID)
        {
            projekat_status_prevod result = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_PROJECT_STATUS_NAME,conn);
                comm.Prepare();
                comm.Parameters.AddWithValue("JEZIK_ID", languageID);
                comm.Parameters.AddWithValue("PROJEKAT_STATUS_ID", statusID);
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    result = new projekat_status_prevod();
                    result.JEZIK_ID = languageID;
                    result.Naziv = reader.GetString("Naziv");
                    result.PROJEKAT_STATUS_ID = statusID;
                    result.Opis = reader.GetString("Opis");
                }
            }
            return result;
        }

        public projekat GetProjectByID(int ID)
        {
            projekat result = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_PROJECT_BY_ID, conn);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    result = new projekat();
                    result.ID = reader.GetInt32("ID");
                    result.Naziv = reader.GetString("Naziv");
                    result.Opis = reader.GetString("Opis");
                    result.DatumPocetka = reader.GetDateTime("DatumPocetka");
                    result.DatumZavrsetka = reader.GetDateTime("DatumZavrsetka");
                    result.ProcenatZavrsenosti = reader.GetDecimal("ProcenatZavrsenosti");
                    result.Budzet = reader.GetDecimal("Budzet");
                    result.FK_ProjekatStatusID = reader.GetInt32("FK_ProjekatStatusID");
                    result.FK_TeritorijalnaJedinica_ID = reader.GetInt32("FK_TeritorijalnaJedinica_ID");
                }
            }

            return result;
        }

        public List<projekat_status_prevod> GetAllProjectStatuses(int languageID)
        {
            List<projekat_status_prevod> result = new List<projekat_status_prevod>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(LIST_PROJECT_STATUSES, conn);
                comm.Parameters.AddWithValue("JEZIK_ID", languageID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    projekat_status_prevod psp = new projekat_status_prevod();
                    psp.Naziv = reader.GetString("Naziv");
                    psp.JEZIK_ID = reader.GetInt32("JEZIK_ID");
                    psp.PROJEKAT_STATUS_ID = reader.GetInt32("PROJEKAT_STATUS_ID");
                    result.Add(psp);
                }
            }

            return result;
        }

        public projekat GetLastCreatedProject()
        {
            
            if (LAST_INSERTED_ID > 0)
            {
                return (GetProjectByID((int)LAST_INSERTED_ID));
            }
            else
            {
                return null;
            }

            
        }

        public bool UpdateProject(int ID, string name, string description, DateTime dateStart, DateTime dateEnd, decimal budget, decimal percentage, int projectstatusID, int teritoryunitID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(UPDATE_PROJECT, conn);
                comm.Parameters.AddWithValue("Naziv", name);
                comm.Parameters.AddWithValue("Opis", description);
                comm.Parameters.AddWithValue("DatumPocetka", dateStart);
                comm.Parameters.AddWithValue("DatumZavrsetka", dateEnd);
                comm.Parameters.AddWithValue("Budzet", budget);
                comm.Parameters.AddWithValue("ProcenatZavrsenosti", percentage);
                comm.Parameters.AddWithValue("FK_ProjekatStatusID", projectstatusID);
                comm.Parameters.AddWithValue("FK_TeritorijalnaJedinica_ID", teritoryunitID);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return result;
        }

        public List<projekat> SearchProjects(string search)
        {
            List<projekat> result = new List<projekat>();

            MySqlParameter[] parameters = new MySqlParameter[1];
            parameters[0] = new MySqlParameter("upit", "%"+search+"%");
            MySqlDataReader reader = MySqlHelper.ExecuteReader(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString, SEARCH_PROJECTS, parameters);

            while (reader.Read())
            {
                projekat project = new projekat();
                project.ID = reader.GetInt32("ID");
                project.Naziv = reader.GetString("Naziv");
                project.Opis = reader.GetString("Opis");
                project.DatumPocetka = reader.GetDateTime("DatumPocetka");
                project.DatumZavrsetka = reader.GetDateTime("DatumZavrsetka");
                project.ProcenatZavrsenosti = reader.GetDecimal("ProcenatZavrsenosti");
                project.Budzet = reader.GetDecimal("Budzet");
                project.FK_ProjekatStatusID = reader.GetInt32("FK_ProjekatStatusID");
                project.FK_TeritorijalnaJedinica_ID = reader.GetInt32("FK_TeritorijalnaJedinica_ID");
                result.Add(project);
            }

            return result;
        }

        public List<projekat> ListProjectByTerritorySearch(int territoryid, string search)
        {
            List<projekat> result = new List<projekat>();

            MySqlParameter[] parameters = new MySqlParameter[2];
            parameters[0] = new MySqlParameter("upit", "%" + search + "%");
            parameters[1] = new MySqlParameter("FK_TeritorijalnaJedinica_ID", territoryid);
            MySqlDataReader reader = MySqlHelper.ExecuteReader(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString, SEARCH_PROJECTS, parameters);

            while (reader.Read())
            {
                projekat project = new projekat();
                project.ID = reader.GetInt32("ID");
                project.Naziv = reader.GetString("Naziv");
                project.Opis = reader.GetString("Opis");
                project.DatumPocetka = reader.GetDateTime("DatumPocetka");
                project.DatumZavrsetka = reader.GetDateTime("DatumZavrsetka");
                project.ProcenatZavrsenosti = reader.GetDecimal("ProcenatZavrsenosti");
                project.Budzet = reader.GetDecimal("Budzet");
                project.FK_ProjekatStatusID = reader.GetInt32("FK_ProjekatStatusID");
                project.FK_TeritorijalnaJedinica_ID = reader.GetInt32("FK_TeritorijalnaJedinica_ID");
                result.Add(project);
            }

            return result;
        }




    }
}
