﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Configuration;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO
{
    class Projekat_MentorDAO
    {
        private string DELETE_PROJECT_MENTOR_CONNECTIONS = @"DELETE FROM PROJEKAT_MENTOR WHERE FK_ProjekatID=?FK_ProjekatID;";
        private string CREATE_PROJECT_MENTOR_CONNECTION = @"INSERT INTO PROJEKAT_MENTOR (FK_ProjekatID, FK_UcesnikProjektaID) VALUES (?FK_ProjekatID, ?FK_UcesnikProjektaID);";
        private string GET_PROJECT_MENTOR_CONNECTION = @"SELECT * FROM PROJEKAT_MENTOR WHERE FK_ProjekatID=?FK_ProjekatID;";


        public projekat_mentor GetProjectMentor(int projectID)
        {
            projekat_mentor result = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_PROJECT_MENTOR_CONNECTION, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    result = new projekat_mentor();
                    result.ID = reader.GetInt32("ID");
                    result.FK_ProjekatID = reader.GetInt32("FK_ProjekatID");
                    result.FK_UcesnikProjektaID = reader.GetInt32("FK_UcesnikProjektaID");
                }
            }

            return result;
        }

        public bool CreateProjectMentor(int projectID, int mentorID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(CREATE_PROJECT_MENTOR_CONNECTION, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Parameters.AddWithValue("FK_UcesnikProjektaID", mentorID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    return true;
                }
            }

            return result;
        }

        public bool DeleteProjectMentor(int projectID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(DELETE_PROJECT_MENTOR_CONNECTIONS, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    return true;
                }

            }

            return result;
        } 

    }
}
