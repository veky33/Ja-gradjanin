﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO
{
    class KorisnikDAO
    {
        private string LIST_ALL_USERS = @"SELECT ID, Ime, Prezime, KorisnickoIme, Status, FK_VrstaKorisnika_VrstaKorisnikaID, FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID FROM KORISNIK;";
        private string LIST_ALL_ACTIVE_USERS = @"SELECT ID, Ime, Prezime, KorisnickoIme, Status, FK_VrstaKorisnika_VrstaKorisnikaID, FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID FROM KORISNIK WHERE Status=1;";
        private string GET_SPECIFIC_USER_BY_USERNAME = @"SELECT ID, Ime, Prezime, KorisnickoIme, Status, FK_VrstaKorisnika_VrstaKorisnikaID, FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID FROM KORISNIK WHERE KorisnickoIme=?KorisnickoIme;";
        private string CREATE_USER = @"INSERT INTO KORISNIK (Ime, Prezime, KorisnickoIme, LozinkaHash, IzabraniJezik, FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID,FK_VrstaKorisnika_VrstaKorisnikaID) VALUES (?Ime, ?Prezime, ?KorisnickoIme, ?LozinkaHash, ?IzabraniJezik, ?FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID, ?FK_VrstaKorisnika_VrstaKorisnikaID);";
        private string UPDATE_USER = @"UPDATE KORISNIK SET Ime=?Ime, Prezime=?Prezime, KorisnickoIme=?KorisnickoIme, IzabraniJezik=?IzabraniJezik, FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID=?FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID, FK_VrstaKorisnika_VrstaKorisnikaID=?FK_VrstaKorisnika_VrstaKorisnikaID WHERE ID=?ID;";
        private string SET_USER_STATUS = @"UPDATE KORISNIK SET Status=?Status WHERE ID=?ID;"; // "deleting" user
        private string SET_PASSWORD = @"UPDATE KORISNIK SET LozinkaHash=?LozinkaHash WHERE ID=?ID;";
        private string GET_PASSWORD = @"SELECT LozinkaHash FROM KORISNIK WHERE KorisnickoIme=?KorisnickoIme;";
        private string GET_SPECIFIC_USER_BY_ID = @"SELECT ID, Ime, Prezime, KorisnickoIme, Status, FK_VrstaKorisnika_VrstaKorisnikaID, FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID FROM KORISNIK WHERE ID=?ID;";
        private string GET_USER_TYPES = @"SELECT * FROM KORISNIK_VRSTA";


        /// <summary>
        /// Returns all users in database
        /// </summary>
        /// <param name="activeOnly">If true, method will return only active users</param>
        /// <returns></returns>
        public List<korisnik> ListAllUsers(bool activeOnly)
        {
            List<korisnik> usersList = new List<korisnik>();
            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm;
                if (activeOnly)
                {
                    comm = new MySqlCommand(LIST_ALL_ACTIVE_USERS,conn);
                } else
                {
                    comm = new MySqlCommand(LIST_ALL_USERS,conn);
                }

                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                korisnik user;
                while(reader.Read())
                {
                    user = new korisnik();
                    user.ID = reader.GetInt32("ID");
                    user.Ime = reader["Ime"].ToString();
                    user.Prezime = reader.GetString("Prezime");
                    user.KorisnickoIme = reader.GetString("KorisnickoIme");
                    user.Status = reader.GetBoolean("Status");
                    user.FK_VrstaKorisnika_VrstaKorisnikaID = reader.GetInt32("FK_VrstaKorisnika_VrstaKorisnikaID");
                    user.FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID = reader.GetInt32("FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID");
                    usersList.Add(user);
                }
            }
            return usersList;
        } 

        public korisnik GetSpecificUserByUsername (string username)
        {
            korisnik user = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_SPECIFIC_USER_BY_USERNAME, conn);
                comm.Parameters.AddWithValue("KorisnickoIme", username);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    user = new korisnik();
                    user.KorisnickoIme = username;
                    user.ID = reader.GetInt32("ID");
                    user.Ime = reader["Ime"].ToString();
                    user.Prezime = reader.GetString("Prezime");
                    user.Status = reader.GetBoolean("Status");
                    user.FK_VrstaKorisnika_VrstaKorisnikaID = reader.GetInt32("FK_VrstaKorisnika_VrstaKorisnikaID");
                    user.FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID = reader.GetInt32("FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID");
                    
                }
            }

            return user;
        }

        public korisnik GetSpecificUserByID(int ID)
        {
            korisnik user = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_SPECIFIC_USER_BY_ID, conn);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    user = new korisnik();
                    user.KorisnickoIme = reader.GetString("KorisnickoIme");
                    user.ID = reader.GetInt32("ID");
                    user.Ime = reader["Ime"].ToString();
                    user.Prezime = reader.GetString("Prezime");
                    user.Status = reader.GetBoolean("Status");
                    user.FK_VrstaKorisnika_VrstaKorisnikaID = reader.GetInt32("FK_VrstaKorisnika_VrstaKorisnikaID");
                    user.FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID = reader.GetInt32("FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID");

                }
            }

            return user;
        }

        /// <summary>
        /// Method used for creating new user. It will return treue if querry was successfull and false if it was not successful
        /// </summary>
        /// <param name="name"></param>
        /// <param name="surname"></param>
        /// <param name="userName"></param>
        /// <param name="passwordHash"></param>
        /// <param name="language"></param>
        /// <param name="usertype"></param>
        /// <param name="teritoryUnit"></param>
        /// <returns></returns>
        public bool CreateUser(string name, string surname, string userName, string passwordHash, int language, int usertype, int teritoryUnit)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(CREATE_USER, conn);
                comm.Parameters.AddWithValue("Ime", name);
                comm.Parameters.AddWithValue("Prezime", surname);
                comm.Parameters.AddWithValue("KorisnickoIme", userName);
                comm.Parameters.AddWithValue("LozinkaHash", passwordHash);
                comm.Parameters.AddWithValue("IzabraniJezik", language);
                comm.Parameters.AddWithValue("FK_VrstaKorisnika_VrstaKorisnikaID", usertype);
                comm.Parameters.AddWithValue("FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID", teritoryUnit);
                comm.Prepare();
                int query = comm.ExecuteNonQuery();
                if (query != -1)
                {
                    result = true;
                }
            }

            return result;
        }


        public bool UpdateUser(int ID, string name, string surname, string userName, int language, int usertype, int teritoryUnit)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(UPDATE_USER, conn);
                comm.Parameters.AddWithValue("Ime", name);
                comm.Parameters.AddWithValue("Prezime", surname);
                comm.Parameters.AddWithValue("KorisnickoIme", userName);
                comm.Parameters.AddWithValue("IzabraniJezik", language);
                comm.Parameters.AddWithValue("FK_VrstaKorisnika_VrstaKorisnikaID", usertype);
                comm.Parameters.AddWithValue("FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID", teritoryUnit);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                int query = comm.ExecuteNonQuery();
                if (query != -1)
                {
                    result = true;
                }
            }

            return result;
        }

        public bool SetUserStatus(bool status, int ID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(SET_USER_STATUS, conn);
                comm.Parameters.AddWithValue("Status", status);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                int query = comm.ExecuteNonQuery();
                if (query != -1)
                {
                    result = true;
                }
            }

            return result;
        }

        public string GetPasswordHash(string username)
        {
            string passwordHash = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString)) {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_PASSWORD, conn);
                comm.Parameters.AddWithValue("KorisnickoIme", username);
                MySqlDataReader reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    passwordHash = reader.GetString("LozinkaHash");
                }
            }

            return passwordHash;
        }

        public string GetPasswordHashbyID(string ID)
        {
            string passwordHash = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_PASSWORD, conn);
                comm.Parameters.AddWithValue("ID", ID);
                MySqlDataReader reader = comm.ExecuteReader();
                if (reader.Read())
                {
                    passwordHash = reader.GetString("LozinkaHash");
                }
            }

            return passwordHash;
        }

        public bool SetPasswordHash(string passwordHash, int ID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(SET_PASSWORD, conn);
                comm.Parameters.AddWithValue("LozinkaHash", passwordHash);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                int query = comm.ExecuteNonQuery();
                if (query != -1)
                {
                    result = true;
                }
            }

            return result;
        }

        public List<korisnik_vrsta> GetUserTypes()
        {
            List<korisnik_vrsta> result = new List<korisnik_vrsta>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_USER_TYPES, conn);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while(reader.Read())
                {
                    korisnik_vrsta k = new korisnik_vrsta();
                    k.ID = reader.GetInt32("ID");
                    k.Naziv = reader.GetString("Naziv");
                    k.Opis = reader.GetString("Opis");
                    result.Add(k);
                }
            }

            return result;
        }

    }
}
