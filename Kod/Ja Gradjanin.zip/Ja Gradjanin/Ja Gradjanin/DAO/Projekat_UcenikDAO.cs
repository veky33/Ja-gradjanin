﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO
{
    class Projekat_UcenikDAO
    {
        private string GET_STUDENTS = @"SELECT * FROM PROJEKAT_UCENIK WHERE FK_ProjekatID=?FK_ProjekatID;";
        private string CREATE_STUDENT = @"INSERT INTO PROJEKAT_UCENIK (FK_ProjekatID, FK_UcesnikProjektaID) VALUES (?FK_ProjekatID, ?FK_UcesnikProjektaID);";
        private string DELETE_STUDENTS = @"DELETE FROM PROJEKAT_UCENIK WHERE FK_ProjekatID=?FK_ProjekatID;";

        public List<projekat_ucenik> GetAllProjectStudents(int projectID)
        {
            List<projekat_ucenik> result = new List<projekat_ucenik>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_STUDENTS, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    projekat_ucenik pu = new projekat_ucenik();
                    pu.ID = reader.GetInt32("ID");
                    pu.FK_ProjekatID = reader.GetInt32("FK_ProjekatID");
                    pu.FK__UcesnikProjektaID = reader.GetInt32("FK_UcesnikProjektaID");
                    result.Add(pu);
                }
            }

            return result;
        }

        public bool CreateProjectStudent(int projectID, int studentID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(CREATE_STUDENT, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Parameters.AddWithValue("FK_UcesnikProjektaID", studentID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return true;
        }

        public bool DeleteProjectStudents(int projectID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(DELETE_STUDENTS, conn);
                comm.Parameters.AddWithValue("FK_ProjekatID", projectID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return true;
        }
    }
}
