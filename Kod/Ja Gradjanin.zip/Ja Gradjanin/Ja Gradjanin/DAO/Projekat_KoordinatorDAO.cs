﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace Ja_Gradjanin.DAO
{
    class Projekat_KoordinatorDAO
    {
        private string DELETE_PROJECT_COORDINATOR_CONNECTIONS = @"DELETE FROM PROJEKAT_KOORDINATOR WHERE FK_Projekat_ProjekatID=?FK_Projekat_ProjekatID;";
        private string CREATE_PROJECT_COORDINATOR_CONNECTION = @"INSERT INTO PROJEKAT_KOORDINATOR (FK_Projekat_ProjekatID, FK_Korisnik_KorisnikID) VALUES (?FK_Projekat_ProjekatID, ?FK_Korisnik_KorisnikID);";

        public bool DeleteProjectCoordinatorConnections(int projectID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(DELETE_PROJECT_COORDINATOR_CONNECTIONS, conn);
                comm.Parameters.AddWithValue("FK_Projekat_ProjekatID", projectID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return result;
        }

        public bool CreateProjectCoordinatorConnection (int projectID, int userID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(CREATE_PROJECT_COORDINATOR_CONNECTION, conn);
                comm.Parameters.AddWithValue("FK_Projekat_ProjekatID", projectID);
                comm.Parameters.AddWithValue("FK_Korisnik_KorisnikID", userID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return result;
        }
    }
}
