﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Configuration;
using MySql.Data.MySqlClient;
using Ja_Gradjanin.Model;

namespace Ja_Gradjanin.DAO
{
    class PrihodDAO
    {
        private string GET_PROJECT_INCOMES = @"SELECT * FROM PRIHOD WHERE PROJEKAT_ID=?PROJEKAT_ID;";
        private string GET_SPECIFIC_INCOME = @"SELECT * FROM PRIHOD WHERE ID=?ID;";
        private string CREATE_INCOME = @"INSERT INTO PRIHOD (Opis, NovcaniIznos, FinansiranOd, Datum, PROJEKAT_ID) VALUES (?Opis, ?NovcaniIznos, ?FinansiranOd, ?Datum, ?PROJEKAT_ID);";
        private string UPDATE_INCOME = @"UPDATE PRIHOD SET Opis=?Opis, NovcaniIznos=?NovcaniIznos, FinansiranOd=?FinansiranOd, Datum=?Datum WHERE ID=?ID;";
        private string DELETE_INCOME = @"DELETE FROM PRIHOD WHERE ID=?ID;";
        private string DELETE_PROJECT_INCOMES = @"DELETE FROM PRIHOD WHERE PROJEKAT_ID=?PROJEKAT_ID;";

        public List<prihod> GetProjectIncomes(int projectID)
        {
            List<prihod> result = new List<prihod>();

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_PROJECT_INCOMES, conn);
                comm.Parameters.AddWithValue("PROJEKAT_ID", projectID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    prihod p = new prihod();
                    p.ID = reader.GetInt32("ID");
                    p.Opis = reader.GetString("Opis");
                    p.NovcaniIznos = reader.GetDecimal("NovcaniIznos");
                    p.FinansiranOd = reader.GetString("FinansiranOd");
                    p.Datum = reader.GetDateTime("Datum");
                    p.PROJEKAT_ID = reader.GetInt32("PROJEKAT_ID");
                    result.Add(p);
                }
            }

            return result;
        }

        public prihod GetSpecificIncome(int ID)
        {
            prihod result = null;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(GET_SPECIFIC_INCOME, conn);
                comm.Parameters.AddWithValue("ID", ID);
                comm.Prepare();
                MySqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    result = new prihod();
                    result.ID = reader.GetInt32("ID");
                    result.Opis = reader.GetString("Opis");
                    result.NovcaniIznos = reader.GetDecimal("NovcaniIznos");
                    result.FinansiranOd = reader.GetString("FinansiranOd");
                    result.Datum = reader.GetDateTime("Datum");
                    result.PROJEKAT_ID = reader.GetInt32("PROJEKAT_ID");
                }
            }

            return result;
        }

        public bool CreateIncome(string description, decimal amount, string financier, DateTime date, int projectID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(CREATE_INCOME, conn);
                comm.Parameters.AddWithValue("Opis", description);
                comm.Parameters.AddWithValue("NovcaniIznos", amount);
                comm.Parameters.AddWithValue("FinansiranOd", financier);
                comm.Parameters.AddWithValue("Datum", date);
                comm.Parameters.AddWithValue("PROJEKAT_ID", projectID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return result;
        }

        public bool UpdateIncome(int id, string description, decimal amount, string financier, DateTime date)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(UPDATE_INCOME, conn);
                comm.Parameters.AddWithValue("ID", id);
                comm.Parameters.AddWithValue("Opis", description);
                comm.Parameters.AddWithValue("NovcaniIznos", amount);
                comm.Parameters.AddWithValue("FinansiranOd", financier);
                comm.Parameters.AddWithValue("Datum", date);         
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return result;
        }

        public bool DeleteIncome(int incomeID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(DELETE_INCOME, conn);
                comm.Parameters.AddWithValue("ID", incomeID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return result;
        }

        public bool DeleteProjectIncomes(int projectID)
        {
            bool result = false;

            using (MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["Ja_gradjanin"].ConnectionString))
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(DELETE_PROJECT_INCOMES, conn);
                comm.Parameters.AddWithValue("PROJEKAT_ID", projectID);
                comm.Prepare();
                int querry = comm.ExecuteNonQuery();
                if (querry != -1)
                {
                    result = true;
                }
            }

            return result;
        }

    }
}
