﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ja_Gradjanin
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        private void buttonBosnianClick(object sender, EventArgs e)
        {
            Program.SwitchLanguage(Program.Languages.Bosnian);
            ShowLoginForm();
        }

        private void buttonCroatianClick(object sender, EventArgs e)
        {
            Program.SwitchLanguage(Program.Languages.Croatian);
            ShowLoginForm();
        }

        private void buttonSerbianClick(object sender, EventArgs e)
        {
            Program.SwitchLanguage(Program.Languages.Serbian);
            ShowLoginForm();

        }

        private void ShowLoginForm()
        {
            this.Hide();
            Form login = new LoginForm();
            login.ShowDialog();
            this.Close();
        }
    }
}
