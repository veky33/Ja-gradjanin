﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Ja_Gradjanin.Model;

namespace Ja_Gradjanin
{
    public partial class UserEditForm : Form
    {
        private int mode = 1;
        private korisnik user;

        public UserEditForm()
        {
            InitializeComponent();
            LoadLanguage();

            comboBoxUsertype.DataSource = Program.UserController.GetAllUserTypes();
            comboBoxUsertype.DisplayMember = "Naziv";
            //comboBoxUsertype.SelectedItem = null;

            comboBoxState.DataSource = Program.TeritoryController.GetStates();
            comboBoxState.DisplayMember = "Naziv";
            //comboBoxState.SelectedItem = null;

            //comboBoxRegion.SelectedItem = null;
            //comboBoxTown.SelectedItem = null;
        }

        public void LoadLanguage()
        {
            labelName.Text = Program.LanguageResxSet.GetString("name");
            labelSurname.Text = Program.LanguageResxSet.GetString("surname");
            labelUsername.Text = Program.LanguageResxSet.GetString("username");
            labelType.Text = Program.LanguageResxSet.GetString("usertype");
            labelState.Text = Program.LanguageResxSet.GetString("state");
            labelRegion.Text = Program.LanguageResxSet.GetString("region");
            labelTown.Text = Program.LanguageResxSet.GetString("town");
            buttonCancel.Text = Program.LanguageResxSet.GetString("cancel");
            buttonSave.Text = Program.LanguageResxSet.GetString("save");

            labelPassword.Text = Program.LanguageResxSet.GetString("password");
        }

        public void FillComboBoxType()
        {
            List<korisnik_vrsta> types = Program.UserController.GetAllUserTypes();
        }

        public UserEditForm(int userid) : this()
        {
            this.user = Program.UserController.GetUserByID(userid);

            this.mode = 2;

            textBoxName.Text = user.Ime;
            textBoxSurname.Text = user.Prezime;
            textBoxUsername.Text = user.KorisnickoIme;
            
            foreach(korisnik_vrsta kv in comboBoxUsertype.Items)
            {
                if (kv.ID == user.FK_VrstaKorisnika_VrstaKorisnikaID)
                {
                    comboBoxUsertype.SelectedItem = kv;
                    break;
                }
            }

            int stateid = 0;
            int regionid = 0;
            int townid = 0;

            townid = user.FK_TeritorijalnaJedinica_TeritorijalnaJedinicaID;
            regionid = (int)Program.TeritoryController.GetTeritory(townid).FK_NadTeritorijalnaJedinica;

            if (user.FK_VrstaKorisnika_VrstaKorisnikaID != 2)
            {
                townid = (int)Program.TeritoryController.GetTeritory(regionid).FK_NadTeritorijalnaJedinica;
            }


            foreach (teritorijalna_jedinica t in comboBoxState.Items)
            {
                if (t.ID == stateid)
                {
                    comboBoxState.SelectedItem = t;
                    break;
                }
            }
            comboBoxRegionFill();
            foreach (teritorijalna_jedinica t in comboBoxRegion.Items)
            {
                if (t.ID == regionid)
                {
                    comboBoxRegion.SelectedItem = t;
                    break;
                }
            }
            comboBoxTownFill();
            if (user.FK_VrstaKorisnika_VrstaKorisnikaID != 2)
            {
                
                foreach (teritorijalna_jedinica t in comboBoxTown.Items)
                {
                    if (t.ID == townid)
                    {
                        comboBoxTown.SelectedItem = t;
                        break;
                    }
                }
            }   
        

        }

        private void ButtonCancelClicked(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ButtonSaveClicked(object sender, EventArgs e)
        {
            SaveUser();
        }

        private void SaveUser()
        {
            if (mode == 1)
            {
                if (textBoxName.Text != "" && textBoxSurname.Text != "" && textBoxUsername.Text != "" && textBoxPassword1.Text != "" && comboBoxTown.SelectedItem != null)
                {
                    if ( ((korisnik_vrsta)comboBoxUsertype.SelectedItem).ID != 2)
                    {
                        Program.UserController.CreateNewUser(textBoxName.Text, textBoxSurname.Text, textBoxUsername.Text, textBoxPassword1.Text, 3, ((korisnik_vrsta)comboBoxUsertype.SelectedItem).ID, ((teritorijalna_jedinica)comboBoxTown.SelectedItem).ID);
                        this.Close();
                    }
                    else
                    {
                        Program.UserController.CreateNewUser(textBoxName.Text, textBoxSurname.Text, textBoxUsername.Text, textBoxPassword1.Text, 3, ((korisnik_vrsta)comboBoxUsertype.SelectedItem).ID, ((teritorijalna_jedinica)comboBoxRegion.SelectedItem).ID);
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Greška");
                }
            }
            else if (mode == 2)
            {
                if (textBoxName.Text != "" && textBoxSurname.Text != "" && textBoxUsername.Text != "")
                {
                    if (((korisnik_vrsta)comboBoxUsertype.SelectedItem).ID != 2)
                    {
                        Program.UserController.UpdateUser(user.ID, textBoxName.Text, textBoxSurname.Text, textBoxUsername.Text, 3, ((korisnik_vrsta)comboBoxUsertype.SelectedItem).ID, ((teritorijalna_jedinica)comboBoxTown.SelectedItem).ID);
                        this.Close();
                    }
                    else
                    {
                        Program.UserController.UpdateUser(user.ID, textBoxName.Text, textBoxSurname.Text, textBoxUsername.Text, 3, ((korisnik_vrsta)comboBoxUsertype.SelectedItem).ID, ((teritorijalna_jedinica)comboBoxRegion.SelectedItem).ID);
                        this.Close();
                    }


                    if (textBoxPassword1.Text != "")
                    {
                        Program.UserController.ChangePassword(user.ID, textBoxPassword1.Text);
                        this.Close();
                    }
                }
            }
        }

        private void comboBoxStateValueChanged(object sender, EventArgs e)
        {
            if (comboBoxState.SelectedValue == null)
            {
                comboBoxRegionFill();
                comboBoxTownFill();
                comboBoxRegion.Enabled = false;
                comboBoxTown.Enabled = false;
            }
            else
            {
                comboBoxRegionFill();
                comboBoxTownFill();
                comboBoxRegion.Enabled = true;
                comboBoxTown.Enabled = true;
            }
        }

        private void comboBoxRegionFill()
        {
            comboBoxRegion.DataSource = null;
            if (comboBoxState.SelectedValue != null)
            {
                comboBoxRegion.DataSource = Program.TeritoryController.GetSubTeritories(((teritorijalna_jedinica)comboBoxState.SelectedItem).ID, false);
                comboBoxRegion.DisplayMember = "Naziv";
            }

        }

        private void comboBoxTownFill()
        {
            comboBoxTown.DataSource = null;
            if (comboBoxRegion.SelectedValue != null)
            {
                comboBoxTown.DataSource = Program.TeritoryController.GetSubTeritories(((teritorijalna_jedinica)comboBoxRegion.SelectedItem).ID, false);
                comboBoxTown.DisplayMember = "Naziv";
            }
        }

        private void comboBoxRegionValueChanged(object sender, EventArgs e)
        {
            if (!((ComboBox)sender).Focused)
            {
                return;
            }
            comboBoxTownFill();
            comboBoxTown.Enabled = true;
        }
    }
}
