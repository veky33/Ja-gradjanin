﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Ja_Gradjanin.Controllers;
using System.IO;

namespace Ja_Gradjanin
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 


        public enum Languages
        {
            Serbian,
            Croatian,
            Bosnian
        }

        private static Languages language;

        private static ResXResourceSet languageResxSet; //ResX file containing language file
        private static UserController userController = new UserController(); //((UserController instance))
        private static ProjectController projectController = new ProjectController(); //((ProjectController instance))
        private static TeritoryController teritoryController = new TeritoryController();
        private static ParticipantController participantController = new ParticipantController();
        private static FinanceController financeController = new FinanceController();
        private static DocumentController documentController = new DocumentController();

        public static ResXResourceSet LanguageResxSet { get => languageResxSet; set => languageResxSet = value; }
        public static UserController UserController { get => userController; set => userController = value; }
        public static ProjectController ProjectController { get => projectController; set => projectController = value; }
        public static TeritoryController TeritoryController { get => teritoryController; set => teritoryController = value; }
        public static Languages Language { get => language; set => language = value; }
        public static ParticipantController ParticipantController { get => participantController; set => participantController = value; }
        internal static FinanceController FinanceController { get => financeController; set => financeController = value; }
        internal static DocumentController DocumentController { get => documentController; set => documentController = value; }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);



            Application.Run(new StartForm());

         }

        public static void SwitchLanguage(Program.Languages language)
        {
            //languageResxReader = new ResXResourceReader(@"Languages/" + languageCode + ".resx");
            string languageCode = null;

            Language = language;

            if (language == Languages.Serbian)
            {
                languageCode = "sr-la";
            } else if (language == Languages.Croatian)
            {
                languageCode = "hr";
            } else if(language == Languages.Bosnian)
            {
                languageCode = "bs";
            }

            try
            {
                LanguageResxSet = new ResXResourceSet(@"Languages/" + languageCode + @".resx");
            }
            catch (FileNotFoundException e)
            {
                MessageBox.Show(e.Message);
            }
        }
    }
}
